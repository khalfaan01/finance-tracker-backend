// FINTECH-CYBER-BACKEND/services/goalOptimizer.js
export class GoalOptimizer {
  static optimizeGoalAllocation(goals, availableFunds) {
    const activeGoals = goals.filter(goal => goal.isActive && !goal.isCompleted);
    
    if (activeGoals.length === 0 || availableFunds <= 0) {
      return { allocations: [], remaining: availableFunds };
    }

    // Calculate priority scores for each goal
    const goalsWithPriority = activeGoals.map(goal => ({
      ...goal,
      priority: this.calculateGoalPriority(goal)
    })).sort((a, b) => b.priority - a.priority);

    const allocations = [];
    let remaining = availableFunds;

    // Allocate funds based on priority
    goalsWithPriority.forEach(goal => {
      const needed = goal.targetAmount - goal.currentAmount;
      const allocation = Math.min(needed, remaining * (goal.priority / 100));
      
      if (allocation > 0) {
        allocations.push({
          goalId: goal.id,
          goalName: goal.name,
          allocation: Math.round(allocation * 100) / 100,
          priority: goal.priority
        });
        remaining -= allocation;
      }
    });

    return { allocations, remaining: Math.round(remaining * 100) / 100 };
  }

  static calculateGoalPriority(goal) {
    let priority = 50; // Base priority
    
    // Time urgency (days until deadline)
    const daysLeft = Math.ceil((new Date(goal.deadline) - new Date()) / (1000 * 60 * 60 * 24));
    if (daysLeft < 30) priority += 30;
    else if (daysLeft < 90) priority += 15;
    
    // Progress factor (closer to completion gets lower priority)
    const progress = (goal.currentAmount / goal.targetAmount) * 100;
    if (progress < 25) priority += 20;
    else if (progress > 75) priority -= 10;
    
    // Goal importance (you could add an importance field to goals)
    // For now, we'll use target amount as proxy (larger goals get slightly higher priority)
    if (goal.targetAmount > 1000) priority += 5;
    
    return Math.min(100, Math.max(0, priority));
  }
}