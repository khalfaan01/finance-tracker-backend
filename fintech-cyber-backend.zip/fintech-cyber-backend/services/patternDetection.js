// FINTECH-CYBER-BACKEND/services/patternDetection.js
export class PatternDetector {
  static detectSpendingPatterns(transactions) {
    const patterns = {
      recurringPayments: this.detectRecurringPayments(transactions),
      seasonalTrends: this.detectSeasonalTrends(transactions),
      behavioralPatterns: this.detectBehavioralPatterns(transactions),
      anomalyDetections: this.detectAnomalies(transactions)
    };
    
    return patterns;
  }

  static detectRecurringPayments(transactions) {
    const recurring = [];
    const expenseTransactions = transactions.filter(tx => tx.type === 'expense');
    
    // Group by description and amount
    const paymentGroups = {};
    expenseTransactions.forEach(tx => {
      const key = `${tx.description}-${Math.abs(tx.amount)}`;
      if (!paymentGroups[key]) {
        paymentGroups[key] = [];
      }
      paymentGroups[key].push(tx);
    });

    // Find recurring patterns (3+ occurrences with regular intervals)
    Object.entries(paymentGroups).forEach(([key, txs]) => {
      if (txs.length >= 3) {
        const dates = txs.map(tx => new Date(tx.date)).sort((a, b) => a - b);
        const intervals = [];
        
        for (let i = 1; i < dates.length; i++) {
          intervals.push((dates[i] - dates[i-1]) / (1000 * 60 * 60 * 24)); // days between
        }
        
        const avgInterval = intervals.reduce((a, b) => a + b) / intervals.length;
        const isRegular = intervals.every(interval => 
          Math.abs(interval - avgInterval) <= 7 // within 7 days variance
        );

        if (isRegular) {
          recurring.push({
            description: txs[0].description,
            amount: Math.abs(txs[0].amount),
            frequency: avgInterval <= 35 ? 'monthly' : 'yearly',
            occurrences: txs.length,
            nextExpected: new Date(dates[dates.length - 1].getTime() + avgInterval * 24 * 60 * 60 * 1000)
          });
        }
      }
    });

    return recurring;
  }

  static detectSeasonalTrends(transactions) {
    const monthlySpending = {};
    const currentYear = new Date().getFullYear();
    
    transactions
      .filter(tx => tx.type === 'expense' && new Date(tx.date).getFullYear() === currentYear)
      .forEach(tx => {
        const month = new Date(tx.date).getMonth();
        monthlySpending[month] = (monthlySpending[month] || 0) + Math.abs(tx.amount);
      });

    return monthlySpending;
  }

  static detectBehavioralPatterns(transactions) {
    const patterns = {
      weekendSpending: 0,
      weekdaySpending: 0,
      morningSpending: 0,
      eveningSpending: 0
    };

    transactions.forEach(tx => {
      const date = new Date(tx.date);
      const dayOfWeek = date.getDay();
      const hour = date.getHours();
      const amount = Math.abs(tx.amount);

      if (dayOfWeek === 0 || dayOfWeek === 6) {
        patterns.weekendSpending += amount;
      } else {
        patterns.weekdaySpending += amount;
      }

      if (hour >= 18 || hour < 6) {
        patterns.eveningSpending += amount;
      } else {
        patterns.morningSpending += amount;
      }
    });

    return patterns;
  }

  static detectAnomalies(transactions) {
    const anomalies = [];
    const expenseTransactions = transactions.filter(tx => tx.type === 'expense');
    
    if (expenseTransactions.length === 0) return anomalies;

    // Calculate average and standard deviation
    const amounts = expenseTransactions.map(tx => Math.abs(tx.amount));
    const average = amounts.reduce((a, b) => a + b) / amounts.length;
    const stdDev = Math.sqrt(
      amounts.map(x => Math.pow(x - average, 2)).reduce((a, b) => a + b) / amounts.length
    );

    // Find anomalies (3 standard deviations from mean)
    expenseTransactions.forEach(tx => {
      const amount = Math.abs(tx.amount);
      if (amount > average + (3 * stdDev)) {
        anomalies.push({
          transaction: tx,
          deviation: ((amount - average) / stdDev).toFixed(2),
          riskLevel: amount > average + (5 * stdDev) ? 'high' : 'medium'
        });
      }
    });

    return anomalies;
  }

  // Additional backend-specific methods for fraud detection
  static detectFraudPatterns(transactions, userProfile) {
    const fraudIndicators = {
      rapidSuccessionTransactions: this.detectRapidTransactions(transactions),
      unusualLocationPatterns: this.detectLocationAnomalies(transactions, userProfile),
      amountPatternDeviations: this.detectAmountPatterns(transactions, userProfile)
    };

    return fraudIndicators;
  }

  static detectRapidTransactions(transactions) {
    const rapidTransactions = [];
    const sortedTransactions = transactions.sort((a, b) => new Date(a.date) - new Date(b.date));
    
    for (let i = 1; i < sortedTransactions.length; i++) {
      const current = sortedTransactions[i];
      const previous = sortedTransactions[i - 1];
      const timeDiff = new Date(current.date) - new Date(previous.date);
      
      // Flag transactions within 5 minutes of each other
      if (timeDiff < 5 * 60 * 1000 && current.type === 'expense') {
        rapidTransactions.push({
          transaction: current,
          timeFromPrevious: timeDiff / (1000 * 60), // minutes
          riskLevel: 'medium'
        });
      }
    }

    return rapidTransactions;
  }

  static detectLocationAnomalies(transactions, userProfile) {
    // This would integrate with IP geolocation data
    // For now, using a simplified version
    const locations = transactions.map(tx => tx.ipAddress).filter(Boolean);
    const uniqueLocations = [...new Set(locations)];
    
    return {
      uniqueLocations: uniqueLocations.length,
      suspicious: uniqueLocations.length > 3 // More than 3 unique locations might be suspicious
    };
  }

  static detectAmountPatterns(transactions, userProfile) {
    const expenseTransactions = transactions.filter(tx => tx.type === 'expense');
    if (expenseTransactions.length === 0) return { deviations: [] };

    const amounts = expenseTransactions.map(tx => Math.abs(tx.amount));
    const average = amounts.reduce((a, b) => a + b) / amounts.length;
    
    const deviations = expenseTransactions
      .filter(tx => Math.abs(tx.amount) > average * 2) // 2x average amount
      .map(tx => ({
        transaction: tx,
        deviationFromAverage: ((Math.abs(tx.amount) - average) / average * 100).toFixed(1) + '%',
        riskLevel: 'high'
      }));

    return { deviations, averageAmount: average };
  }
}