import nodemailer from 'nodemailer';

class EmailService {
  constructor() {
    this.transporter = nodemailer.createTransporter({
      // For Gmail - you'll need to set up App Password
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS, // Use App Password for Gmail
      },
      
    });
  }

  async sendSecurityAlert(userEmail, alertData) {
    try {
      const mailOptions = {
        from: process.env.EMAIL_USER,
        to: userEmail,
        subject: ` Security Alert: ${alertData.type}`,
        html: this.generateAlertEmail(alertData),
      };

      const result = await this.transporter.sendMail(mailOptions);
      console.log(' Security email sent:', result.messageId);
      return true;
    } catch (error) {
      console.error(' Email sending failed:', error);
      return false;
    }
  }

  generateAlertEmail(alertData) {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; color: #333; }
          .alert { border-left: 4px solid #e74c3c; padding: 15px; background: #fdf2f2; }
          .warning { border-left: 4px solid #f39c12; padding: 15px; background: #fef9e7; }
          .info { border-left: 4px solid #3498db; padding: 15px; background: #f0f8ff; }
        </style>
      </head>
      <body>
        <h2> Security Alert from Sultan's Tracker</h2>
        
        <div class="${alertData.riskLevel === 'high' ? 'alert' : 'warning'}">
          <h3>${alertData.title}</h3>
          <p><strong>Time:</strong> ${new Date(alertData.timestamp).toLocaleString()}</p>
          <p><strong>Risk Level:</strong> ${alertData.riskLevel.toUpperCase()}</p>
          <p><strong>Details:</strong> ${alertData.message}</p>
          ${alertData.ip ? `<p><strong>IP Address:</strong> ${alertData.ip}</p>` : ''}
          ${alertData.location ? `<p><strong>Location:</strong> ${alertData.location}</p>` : ''}
        </div>

        <div class="info">
          <h4>Recommended Actions:</h4>
          <ul>
            ${alertData.recommendedActions?.map(action => `<li>${action}</li>`).join('') || `
            <li>Review this activity in your Security Dashboard</li>
            <li>Contact support if you didn't perform this action</li>
            <li>Consider changing your password</li>
            `}
          </ul>
        </div>

        <p><small>If this wasn't you, please secure your account immediately.</small></p>
        
        <hr>
        <p><small>This is an automated security alert. Do not reply to this email.</small></p>
      </body>
      </html>
    `;
  }

  // Send different types of alerts
  async sendSuspiciousTransactionAlert(userEmail, transactionData) {
    const alertData = {
      type: 'Suspicious Transaction',
      title: 'Unusual Transaction Detected',
      message: `A transaction of $${Math.abs(transactionData.amount)} was flagged for review.`,
      riskLevel: transactionData.riskScore > 80 ? 'high' : 'medium',
      timestamp: new Date(),
      ip: transactionData.ip,
      location: transactionData.location,
      recommendedActions: [
        'Verify this transaction in your account',
        'Report if unauthorized',
        'Monitor your account for other unusual activity'
      ]
    };

    return this.sendSecurityAlert(userEmail, alertData);
  }

  async sendUnusualLoginAlert(userEmail, loginData) {
    const alertData = {
      type: 'Unusual Login',
      title: 'Login from New Location',
      message: `Your account was accessed from a new location.`,
      riskLevel: 'medium',
      timestamp: new Date(),
      ip: loginData.ip,
      location: `${loginData.city}, ${loginData.country}`,
      recommendedActions: [
        'Verify this was you',
        'Change password if suspicious',
        'Enable two-factor authentication'
      ]
    };

    return this.sendSecurityAlert(userEmail, alertData);
  }

  async sendHighRiskAlert(userEmail, securityData) {
    const alertData = {
      type: 'High Risk Activity',
      title: 'Critical Security Event',
      message: securityData.message,
      riskLevel: 'high',
      timestamp: new Date(),
      ip: securityData.ip,
      recommendedActions: [
        'Immediately change your password',
        'Contact support',
        'Review recent account activity'
      ]
    };

    return this.sendSecurityAlert(userEmail, alertData);
  }
}

export default new EmailService();