export class MoodAnalysisService {
  static analyzeMoodPatterns(moods, transactions) {
    const analysis = {
      emotionalSpending: 0,
      plannedSpending: 0,
      correlation: {},
      trends: {},
      insights: []
    };

    // Calculate spending by mood
    moods.forEach(mood => {
      const transaction = transactions.find(t => t.id === mood.transactionId);
      if (transaction) {
        const amount = Math.abs(transaction.amount);
        
        if (['stressed', 'anxious', 'bored'].includes(mood.mood)) {
          analysis.emotionalSpending += amount;
        } else if (mood.mood === 'planned') {
          analysis.plannedSpending += amount;
        }

        // Build correlation data
        if (!analysis.correlation[mood.mood]) {
          analysis.correlation[mood.mood] = { total: 0, count: 0, average: 0 };
        }
        analysis.correlation[mood.mood].total += amount;
        analysis.correlation[mood.mood].count += 1;
        analysis.correlation[mood.mood].average = 
          analysis.correlation[mood.mood].total / analysis.correlation[mood.mood].count;
      }
    });

    // Generate insights
    if (analysis.emotionalSpending > analysis.plannedSpending) {
      analysis.insights.push({
        type: 'behavioral',
        title: 'Emotional Spending Dominance',
        message: `You spend $${analysis.emotionalSpending.toFixed(2)} when emotional vs $${analysis.plannedSpending.toFixed(2)} on planned purchases`,
        severity: 'medium',
        recommendation: 'Practice mindful spending by waiting 24 hours before emotional purchases'
      });
    }

    // Find highest spending mood
    const highestMood = Object.entries(analysis.correlation)
      .reduce((max, [mood, data]) => data.average > max.average ? { mood, ...data } : max, { mood: '', average: 0 });

    if (highestMood.mood) {
      analysis.insights.push({
        type: 'pattern',
        title: 'Highest Spending Mood',
        message: `You spend the most when feeling ${highestMood.mood} ($${highestMood.average.toFixed(2)} on average)`,
        severity: 'low',
        recommendation: 'Be particularly mindful of spending when feeling this way'
      });
    }

    return analysis;
  }

  static predictMoodImpact(transactions, currentMood) {
    const similarMoodTransactions = transactions.filter(t => 
      t.mood && t.mood.mood === currentMood
    );

    if (similarMoodTransactions.length === 0) return null;

    const avgAmount = similarMoodTransactions.reduce((sum, t) => sum + Math.abs(t.amount), 0) / similarMoodTransactions.length;
    const categories = {};
    
    similarMoodTransactions.forEach(t => {
      categories[t.category] = (categories[t.category] || 0) + 1;
    });

    const mostCommonCategory = Object.entries(categories)
      .reduce((max, [cat, count]) => count > max.count ? { category: cat, count } : max, { category: '', count: 0 });

    return {
      predictedSpending: avgAmount,
      likelyCategories: mostCommonCategory.category,
      confidence: similarMoodTransactions.length > 5 ? 'high' : 'medium',
      warning: avgAmount > 100 ? 'High spending predicted in this mood state' : null
    };
  }
}