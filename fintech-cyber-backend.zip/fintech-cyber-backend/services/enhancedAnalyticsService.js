import { PatternDetector } from './patternDetection.js';
import { PredictiveBudgeting } from './predictiveBudgeting.js';
import { GoalOptimizer } from './goalOptimizer.js';

export class EnhancedAnalyticsService {
  // Enhanced: Comprehensive analysis with new features
  static async getEnhancedComprehensiveAnalysis(userId, prisma, timeframe) {
    try {
      const [transactions, budgets, goals, accounts] = await Promise.all([
        prisma.transaction.findMany({
          where: { account: { userId } },
          include: { mood: true, account: true }
        }),
        prisma.budget.findMany({ where: { userId } }),
        prisma.financialGoal.findMany({ where: { userId } }),
        prisma.account.findMany({ where: { userId } })
      ]);

      const patterns = PatternDetector.detectSpendingPatterns(transactions);
      const budgetRecommendations = PredictiveBudgeting.generateSmartBudgets(transactions, budgets);
      const goalOptimization = GoalOptimizer.optimizeGoalAllocation(goals, 1000);
      const securityInsights = this.generateSecurityInsights(transactions);
      
      // NEW: Enhanced analytics
      const cashFlowAnalysis = this.analyzeCashFlow(transactions, 'daily', userId);
      const incomeBreakdown = this.analyzeIncomeStreams(transactions);
      const spendingForecast = this.generateSpendingForecast(transactions, 30);
      const contextualInsights = this.generateContextualInsights(transactions);

      return {
        patterns,
        budgetRecommendations,
        goalOptimization,
        securityInsights,
        cashFlowAnalysis,
        incomeBreakdown,
        spendingForecast,
        contextualInsights,
        summary: this.generateEnhancedSummary(
          patterns, 
          budgetRecommendations, 
          goalOptimization,
          cashFlowAnalysis,
          spendingForecast
        )
      };
    } catch (error) {
      console.error('Enhanced analytics error:', error);
      throw error;
    }
  }

  // NEW: Advanced Cash Flow Analysis
  static analyzeCashFlow(transactions, granularity, userId) {
    const analysis = {
      granularity,
      periods: [],
      trends: {},
      insights: []
    };

    const now = new Date();
    let periodData = [];

    // Group by granularity (daily, weekly, monthly)
    switch (granularity) {
      case 'daily':
        // Last 30 days of daily data
        for (let i = 29; i >= 0; i--) {
          const date = new Date(now);
          date.setDate(now.getDate() - i);
          const dateKey = date.toISOString().split('T')[0];
          
          const dayTransactions = transactions.filter(tx => {
            const txDate = new Date(tx.date).toISOString().split('T')[0];
            return txDate === dateKey;
          });

          const income = dayTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
          const expenses = dayTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + Math.abs(t.amount), 0);
          const net = income - expenses;

          periodData.push({
            date: dateKey,
            income,
            expenses,
            net,
            transactionCount: dayTransactions.length
          });
        }
        break;

      case 'weekly':
        // Last 12 weeks
        for (let i = 11; i >= 0; i--) {
          const weekStart = new Date(now);
          weekStart.setDate(now.getDate() - (i * 7));
          const weekKey = `Week ${i + 1}`;
          
          const weekEnd = new Date(weekStart);
          weekEnd.setDate(weekStart.getDate() + 6);

          const weekTransactions = transactions.filter(tx => {
            const txDate = new Date(tx.date);
            return txDate >= weekStart && txDate <= weekEnd;
          });

          const income = weekTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
          const expenses = weekTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + Math.abs(t.amount), 0);
          const net = income - expenses;

          periodData.push({
            period: weekKey,
            startDate: weekStart.toISOString().split('T')[0],
            endDate: weekEnd.toISOString().split('T')[0],
            income,
            expenses,
            net,
            transactionCount: weekTransactions.length
          });
        }
        break;
    }

    analysis.periods = periodData;

    // Calculate trends
    if (periodData.length > 1) {
      const firstPeriod = periodData[0];
      const lastPeriod = periodData[periodData.length - 1];
      
      analysis.trends = {
        incomeGrowth: ((lastPeriod.income - firstPeriod.income) / firstPeriod.income * 100) || 0,
        expenseGrowth: ((lastPeriod.expenses - firstPeriod.expenses) / firstPeriod.expenses * 100) || 0,
        netGrowth: ((lastPeriod.net - firstPeriod.net) / Math.abs(firstPeriod.net) * 100) || 0,
        volatility: this.calculateVolatility(periodData.map(p => p.net))
      };
    }

    // Generate insights
    analysis.insights = this.generateCashFlowInsights(periodData);

    return analysis;
  }

  // NEW: Income Stream Analysis
  static analyzeIncomeStreams(incomeTransactions) {
    const streams = {};
    
    incomeTransactions.forEach(tx => {
      // Categorize income by description patterns
      let streamType = 'Other';
      const desc = tx.description?.toLowerCase() || '';
      
      if (desc.includes('salary') || desc.includes('payroll')) streamType = 'Salary';
      else if (desc.includes('freelance') || desc.includes('contract')) streamType = 'Freelance';
      else if (desc.includes('investment') || desc.includes('dividend')) streamType = 'Investment';
      else if (desc.includes('bonus')) streamType = 'Bonus';
      else if (desc.includes('side') || desc.includes('gig')) streamType = 'Side Hustle';
      
      if (!streams[streamType]) {
        streams[streamType] = { total: 0, transactions: [], percentage: 0 };
      }
      
      streams[streamType].total += tx.amount;
      streams[streamType].transactions.push(tx);
    });

    // Calculate percentages
    const totalIncome = Object.values(streams).reduce((sum, stream) => sum + stream.total, 0);
    Object.keys(streams).forEach(stream => {
      streams[stream].percentage = totalIncome > 0 ? (streams[stream].total / totalIncome) * 100 : 0;
    });

    return {
      streams,
      totalIncome,
      streamCount: Object.keys(streams).length,
      primaryStream: Object.keys(streams).reduce((a, b) => streams[a].total > streams[b].total ? a : b, 'None'),
      diversityScore: this.calculateIncomeDiversity(streams)
    };
  }

  // NEW: Spending Forecast
  static generateSpendingForecast(transactions, days = 30) {
    const forecast = {
      period: days,
      dailyProjections: [],
      confidence: 'medium',
      riskFactors: [],
      recommendations: []
    };

    const expenseTransactions = transactions.filter(t => t.type === 'expense');
    if (expenseTransactions.length === 0) return forecast;

    // Simple forecasting based on historical averages
    const totalExpenses = expenseTransactions.reduce((sum, tx) => sum + Math.abs(tx.amount), 0);
    const avgDailyExpense = totalExpenses / Math.max(30, expenseTransactions.length);
    
    const now = new Date();
    for (let i = 1; i <= days; i++) {
      const projectionDate = new Date(now);
      projectionDate.setDate(now.getDate() + i);
      
      // Simple projection with some randomness
      const projectedAmount = avgDailyExpense * (0.8 + Math.random() * 0.4);
      
      forecast.dailyProjections.push({
        date: projectionDate.toISOString().split('T')[0],
        projectedAmount: Math.max(0, projectedAmount),
        confidence: i > 7 ? 'low' : 'medium'
      });
    }

    return forecast;
  }

  // NEW: Contextual Spending Insights
  static generateContextualInsights(transactions) {
    const insights = {
      timeBased: {},
      categoryPatterns: {},
      behavioralInsights: [],
      optimizationOpportunities: []
    };

    // Time-based analysis
    transactions.forEach(tx => {
      const txDate = new Date(tx.date);
      const hour = txDate.getHours();
      
      let timeSlot = 'Morning';
      if (hour >= 12 && hour < 17) timeSlot = 'Afternoon';
      else if (hour >= 17) timeSlot = 'Evening';
      
      if (!insights.timeBased[timeSlot]) {
        insights.timeBased[timeSlot] = { total: 0, count: 0, average: 0 };
      }
      insights.timeBased[timeSlot].total += Math.abs(tx.amount);
      insights.timeBased[timeSlot].count += 1;
    });

    // Calculate averages
    Object.keys(insights.timeBased).forEach(slot => {
      insights.timeBased[slot].average = insights.timeBased[slot].total / insights.timeBased[slot].count;
    });

    return insights;
  }

  // Helper methods
  static calculateVolatility(data) {
    if (data.length < 2) return 0;
    const mean = data.reduce((sum, val) => sum + val, 0) / data.length;
    const variance = data.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / data.length;
    return Math.sqrt(variance);
  }

  static calculateIncomeDiversity(streams) {
    const percentages = Object.values(streams).map(stream => stream.percentage);
    const maxPercentage = Math.max(...percentages);
    return Math.max(0, 100 - maxPercentage);
  }

  static generateCashFlowInsights(periodData) {
    const insights = [];
    const negativeDays = periodData.filter(day => day.net < 0).length;

    if (negativeDays > periodData.length * 0.3) {
      insights.push({
        type: 'negative_cash_flow',
        severity: 'high',
        message: `${negativeDays} periods with negative cash flow detected`,
        recommendation: 'Focus on reducing expenses or increasing income sources'
      });
    }

    return insights;
  }

  static generateEnhancedSummary(patterns, budgets, goals, cashFlow, forecast) {
    return {
      totalPatterns: patterns.recurringPayments?.length + patterns.anomalyDetections?.length || 0,
      budgetOpportunities: budgets.length,
      goalOptimizations: goals.length,
      cashFlowHealth: cashFlow.insights.length === 0 ? 'healthy' : 'needs_attention',
      forecastConfidence: forecast.confidence,
      overallHealth: this.calculateEnhancedFinancialHealth(patterns, budgets, goals, cashFlow, forecast)
    };
  }

  static calculateEnhancedFinancialHealth(patterns, budgets, goals, cashFlow, forecast) {
    let score = 100;
    
    // Basic scoring logic
    score -= cashFlow.insights.filter(insight => insight.severity === 'high').length * 10;
    score -= forecast.riskFactors.length * 5;
    
    return Math.max(0, Math.min(100, score));
  }

  static generateSecurityInsights(transactions) {
    return {
      riskScore: 85,
      anomalies: [],
      behavioralPatterns: {},
      recommendations: []
    };
  }
}