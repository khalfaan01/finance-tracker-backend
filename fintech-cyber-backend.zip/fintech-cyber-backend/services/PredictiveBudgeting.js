// FINTECH-CYBER-BACKEND/services/predictiveBudgeting.js
export class PredictiveBudgeting {
  static generateSmartBudgets(transactions, existingBudgets) {
    const categorySpending = this.analyzeCategorySpending(transactions);
    const recommendations = [];
    
    Object.entries(categorySpending).forEach(([category, data]) => {
      const existingBudget = existingBudgets.find(b => b.category === category);
      const recommendedLimit = this.calculateOptimalBudget(data);
      
      recommendations.push({
        category,
        currentSpending: data.total,
        recommendedLimit,
        confidence: this.calculateConfidence(data),
        suggestion: existingBudget ? 'adjust' : 'create'
      });
    });
    
    return recommendations;
  }

  static analyzeCategorySpending(transactions) {
    const categoryData = {};
    
    transactions
      .filter(tx => tx.type === 'expense')
      .forEach(tx => {
        const category = tx.category;
        const amount = Math.abs(tx.amount);
        
        if (!categoryData[category]) {
          categoryData[category] = {
            total: 0,
            count: 0,
            amounts: []
          };
        }
        
        categoryData[category].total += amount;
        categoryData[category].count += 1;
        categoryData[category].amounts.push(amount);
      });
    
    return categoryData;
  }

  static calculateOptimalBudget(categoryData) {
    const { total, count, amounts } = categoryData;
    const average = total / count;
    const buffer = average * 0.2; // 20% buffer
    
    return Math.ceil(average + buffer);
  }

  static calculateConfidence(categoryData) {
    const { count, amounts } = categoryData;
    
    if (count < 3) return 'low';
    if (count < 10) return 'medium';
    
    // Calculate coefficient of variation
    const average = categoryData.total / count;
    const variance = amounts.reduce((sum, amount) => sum + Math.pow(amount - average, 2), 0) / count;
    const stdDev = Math.sqrt(variance);
    const cv = stdDev / average;
    
    return cv < 0.5 ? 'high' : 'medium';
  }
}