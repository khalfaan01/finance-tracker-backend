export class TransactionAnalysisService {
  static analyzeSpendingPatterns(transactions, timeRange = 'monthly') {
    const analysis = {
      summary: {},
      trends: {},
      categories: {},
      anomalies: [],
      predictions: {}
    };

    const filteredTransactions = this.filterByTimeRange(transactions, timeRange);
    
    // Basic summary
    analysis.summary = {
      totalIncome: filteredTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0),
      totalExpenses: Math.abs(filteredTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0)),
      netFlow: filteredTransactions.reduce((sum, t) => sum + t.amount, 0),
      transactionCount: filteredTransactions.length
    };

    // Category analysis
    analysis.categories = this.analyzeCategories(filteredTransactions);
    
    // Trend analysis
    analysis.trends = this.analyzeTrends(filteredTransactions, timeRange);
    
    // Anomaly detection
    analysis.anomalies = this.detectAnomalies(filteredTransactions);
    
    // Predictions
    analysis.predictions = this.generatePredictions(analysis.trends, analysis.categories);

    return analysis;
  }

  static analyzeCategories(transactions) {
    const categories = {};
    
    transactions.forEach(tx => {
      if (!categories[tx.category]) {
        categories[tx.category] = { total: 0, count: 0, average: 0, transactions: [] };
      }
      
      const amount = Math.abs(tx.amount);
      categories[tx.category].total += amount;
      categories[tx.category].count += 1;
      categories[tx.category].average = categories[tx.category].total / categories[tx.category].count;
      categories[tx.category].transactions.push(tx);
    });

    // Calculate percentages
    const totalExpenses = Object.values(categories).reduce((sum, cat) => sum + cat.total, 0);
    Object.keys(categories).forEach(category => {
      categories[category].percentage = (categories[category].total / totalExpenses) * 100;
    });

    return categories;
  }

  static analyzeTrends(transactions, timeRange) {
    const trends = {};
    const now = new Date();
    
    // Monthly trends for the past 6 months
    for (let i = 5; i >= 0; i--) {
      const month = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthKey = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, '0')}`;
      
      const monthTransactions = transactions.filter(t => {
        const txDate = new Date(t.date);
        return txDate.getFullYear() === month.getFullYear() && 
               txDate.getMonth() === month.getMonth();
      });

      trends[monthKey] = {
        income: monthTransactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0),
        expenses: Math.abs(monthTransactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0)),
        net: monthTransactions.reduce((sum, t) => sum + t.amount, 0),
        count: monthTransactions.length
      };
    }

    return trends;
  }

  static detectAnomalies(transactions) {
    const anomalies = [];
    const expenseTransactions = transactions.filter(t => t.type === 'expense');
    
    if (expenseTransactions.length === 0) return anomalies;

    const amounts = expenseTransactions.map(t => Math.abs(t.amount));
    const average = amounts.reduce((a, b) => a + b) / amounts.length;
    const stdDev = Math.sqrt(amounts.map(x => Math.pow(x - average, 2)).reduce((a, b) => a + b) / amounts.length);

    expenseTransactions.forEach(tx => {
      const amount = Math.abs(tx.amount);
      const zScore = (amount - average) / stdDev;
      
      if (Math.abs(zScore) > 2) {
        anomalies.push({
          transaction: tx,
          zScore: zScore.toFixed(2),
          deviation: `${((amount - average) / average * 100).toFixed(1)}%`,
          severity: Math.abs(zScore) > 3 ? 'high' : 'medium'
        });
      }
    });

    return anomalies;
  }

  static generatePredictions(trends, categories) {
    const last6Months = Object.values(trends).slice(-6);
    
    if (last6Months.length < 3) return {};

    const avgIncome = last6Months.reduce((sum, m) => sum + m.income, 0) / last6Months.length;
    const avgExpenses = last6Months.reduce((sum, m) => sum + m.expenses, 0) / last6Months.length;
    
    const nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);

    return {
      nextMonth: {
        predictedIncome: avgIncome,
        predictedExpenses: avgExpenses,
        predictedNet: avgIncome - avgExpenses,
        confidence: last6Months.length >= 6 ? 'high' : 'medium'
      },
      highSpendCategories: Object.entries(categories)
        .filter(([_, data]) => data.percentage > 15)
        .map(([category, data]) => ({
          category,
          percentage: data.percentage,
          recommendation: `Consider setting a budget for ${category}`
        }))
    };
  }

  static filterByTimeRange(transactions, timeRange) {
    const now = new Date();
    const cutoff = new Date();
    
    switch (timeRange) {
      case 'weekly':
        cutoff.setDate(now.getDate() - 7);
        break;
      case 'monthly':
        cutoff.setMonth(now.getMonth() - 1);
        break;
      case 'yearly':
        cutoff.setFullYear(now.getFullYear() - 1);
        break;
      default:
        cutoff.setMonth(now.getMonth() - 1);
    }

    return transactions.filter(t => new Date(t.date) >= cutoff);
  }
}