export class SubscriptionAutomationService {
  static async processDueSubscriptions(prisma) {
    const now = new Date();
    const dueSubscriptions = await prisma.recurringTransaction.findMany({
      where: {
        isActive: true,
        nextRunDate: { lte: now },
        OR: [
          { endDate: null },
          { endDate: { gte: now } }
        ]
      },
      include: { account: true }
    });

    const results = [];

    for (const subscription of dueSubscriptions) {
      try {
        // Create transaction
        const transaction = await prisma.transaction.create({
          data: {
            accountId: subscription.accountId,
            amount: subscription.type === 'expense' ? -Math.abs(subscription.amount) : Math.abs(subscription.amount),
            type: subscription.type,
            category: subscription.category,
            description: subscription.description,
            date: new Date(),
            isRecurring: true,
            recurringTransactionId: subscription.id
          }
        });

        // Calculate next run date
        const nextRunDate = this.calculateNextRunDate(subscription, now);
        
        // Update subscription
        await prisma.recurringTransaction.update({
          where: { id: subscription.id },
          data: {
            lastRun: new Date(),
            nextRunDate,
            totalRuns: { increment: 1 }
          }
        });

        results.push({
          subscriptionId: subscription.id,
          transactionId: transaction.id,
          status: 'success',
          amount: transaction.amount,
          description: transaction.description,
          nextRunDate
        });

        // Send notification (optional)
        await this.sendSubscriptionNotification(subscription, transaction);

      } catch (error) {
        results.push({
          subscriptionId: subscription.id,
          status: 'error',
          error: error.message
        });
      }
    }

    return {
      processed: results.length,
      successful: results.filter(r => r.status === 'success').length,
      failed: results.filter(r => r.status === 'error').length,
      details: results
    };
  }

  static calculateNextRunDate(subscription, fromDate) {
    const date = new Date(fromDate);
    
    switch (subscription.frequency) {
      case 'daily':
        date.setDate(date.getDate() + subscription.interval);
        break;
      case 'weekly':
        date.setDate(date.getDate() + (7 * subscription.interval));
        break;
      case 'monthly':
        date.setMonth(date.getMonth() + subscription.interval);
        break;
      case 'yearly':
        date.setFullYear(date.getFullYear() + subscription.interval);
        break;
    }
    
    return date;
  }

  static async sendSubscriptionNotification(subscription, transaction) {
    // Integrate with your notification system
    console.log(`Subscription processed: ${subscription.description} - $${Math.abs(transaction.amount)}`);
    
    // Example: Send email or push notification
    // await emailService.sendSubscriptionAlert(userId, subscription, transaction);
  }

  static async analyzeSubscriptionImpact(userId, prisma) {
    const subscriptions = await prisma.recurringTransaction.findMany({
      where: { userId, isActive: true }
    });

    const totalMonthlyCost = subscriptions
      .filter(s => s.frequency === 'monthly')
      .reduce((sum, s) => sum + (s.type === 'expense' ? s.amount : -s.amount), 0);

    const yearlyProjection = totalMonthlyCost * 12;

    return {
      activeSubscriptions: subscriptions.length,
      totalMonthlyCost,
      yearlyProjection,
      breakdown: subscriptions.map(s => ({
        name: s.description,
        amount: s.amount,
        frequency: s.frequency,
        type: s.type,
        nextCharge: s.nextRunDate
      })),
      recommendations: this.generateSubscriptionRecommendations(subscriptions, totalMonthlyCost)
    };
  }

  static generateSubscriptionRecommendations(subscriptions, monthlyCost) {
    const recommendations = [];
    
    if (monthlyCost > 200) {
      recommendations.push({
        type: 'cost_reduction',
        title: 'High Subscription Costs',
        message: `Your monthly subscriptions cost $${monthlyCost.toFixed(2)}. Consider reviewing unused services.`,
        priority: 'high'
      });
    }

    const duplicateServices = this.findDuplicateServices(subscriptions);
    if (duplicateServices.length > 0) {
      recommendations.push({
        type: 'optimization',
        title: 'Duplicate Services Detected',
        message: `You have multiple similar subscriptions: ${duplicateServices.join(', ')}`,
        priority: 'medium'
      });
    }

    return recommendations;
  }

  static findDuplicateServices(subscriptions) {
    const serviceKeywords = {
      'streaming': ['netflix', 'hulu', 'disney', 'hbo', 'prime video'],
      'music': ['spotify', 'apple music', 'youtube music'],
      'cloud': ['dropbox', 'google drive', 'icloud']
    };

    const duplicates = [];
    
    Object.entries(serviceKeywords).forEach(([category, keywords]) => {
      const matches = subscriptions.filter(s => 
        keywords.some(keyword => s.description.toLowerCase().includes(keyword))
      );
      
      if (matches.length > 1) {
        duplicates.push(category);
      }
    });

    return duplicates;
  }
}