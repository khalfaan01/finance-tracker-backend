// fintech-cyber-backend/server.js
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import mongoSanitize from "express-mongo-sanitize";
import hpp from "hpp";
import { createServer } from "http"; 
import { Server } from "socket.io"; 
import prisma from "./db.js";
import authRoutes from "./routes/auth.js";
import transactionRoutes from "./routes/transactions.js";
import accountRoutes from "./routes/accounts.js";
import budgetRoutes from "./routes/budgets.js";
import goalRoutes from "./routes/goals.js";
import securityRoutes from "./routes/security.js";
import transactionMoodRoutes from "./routes/transactionMoods.js";
import recurringTransactionRoutes from "./routes/recurringTransactions.js";
import analyticsRoutes from "./routes/analytics.js"; // ADD THIS
import debtRoutes from "./routes/debts.js";

dotenv.config();

// Initialize Express and HTTP server
const app = express();
const server = createServer(app);

// Rate limiting 
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  message: { error: "Too many requests from this IP, please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: { error: "Too many login attempts, please try again later." }
});

// CORS 
app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);
    
    const allowedOrigins = [
      "http://localhost:5173",
      "http://127.0.0.1:5173",
      process.env.FRONTEND_URL
    ].filter(Boolean);
    
    if (allowedOrigins.indexOf(origin) !== -1) {
      return callback(null, true);
    } else {
      console.log(' CORS blocked for origin:', origin);
      return callback(new Error('Not allowed by CORS'), false);
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Apply rate limiting
app.use(limiter);

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://cdn.tailwindcss.com"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "http://localhost:5173", "http://127.0.0.1:5173", "ws://localhost:5173"]
    },
  },
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));

app.use(hpp());
app.use(mongoSanitize());
app.use(express.json({ limit: '10kb' }));

// Socket.IO setup
const io = new Server(server, {
  cors: {
    origin: ["http://localhost:5173", "http://127.0.0.1:5173"],
    methods: ["GET", "POST"]
  }
});

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log(' User connected:', socket.id);

  // Join user to their personal room for security alerts
  socket.on('join_user_room', (userId) => {
    socket.join(`user_${userId}`);
    console.log(`User ${userId} joined their security room`);
  });

  // Handle real-time security monitoring
  socket.on('monitor_transaction', (data) => {
    // Broadcast to admin room or process real-time
    socket.to('admin_security').emit('new_transaction_monitor', data);
  });

  socket.on('disconnect', () => {
    console.log(' User disconnected:', socket.id);
  });
});

// Make io accessible to routes
app.use((req, res, next) => {
  req.io = io;
  next();
});

// Apply auth rate limiting to authentication routes
app.use("/api/auth", authLimiter);

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/transactions", transactionRoutes);
app.use("/api/accounts", accountRoutes);
app.use("/api/budgets", budgetRoutes);
app.use("/api/goals", goalRoutes);
app.use("/api/security", securityRoutes);
app.use("/api/transaction-moods", transactionMoodRoutes);
app.use("/api/recurring-transactions", recurringTransactionRoutes);
app.use("/api/analytics", analyticsRoutes); 
app.use("/api/debts", debtRoutes);

// Health check route
app.get("/health", (req, res) => {
  res.status(200).json({ 
    status: "OK", 
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// Test route
app.get("/", (req, res) => res.send("Server is running "));

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error stack:', err.stack);
  
  // Handle JSON parse errors
  if (err.type === 'entity.parse.failed' || err instanceof SyntaxError) {
    return res.status(400).json({ error: 'Invalid JSON in request body' });
  }
  
  // Handle CORS errors
  if (err.message.includes('CORS')) {
    return res.status(403).json({ error: 'CORS policy blocked the request' });
  }
  
  res.status(500).json({ 
    error: process.env.NODE_ENV === 'production' 
      ? 'Something went wrong!' 
      : err.message 
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start server + test DB connection
const PORT = process.env.PORT || 5000;
server.listen(PORT, async () => {
  try {
    await prisma.$connect();
    console.log(` Connected to database`);

    const userCount = await prisma.user.count();
    console.log(` Total users in database: ${userCount}`);

  } catch (err) {
    console.error(" Database connection failed:", err.message);
    process.exit(1);
  }
  console.log(` Server running with Socket.IO at http://localhost:${PORT}`);
  console.log(` Real-time security monitoring enabled`);
});