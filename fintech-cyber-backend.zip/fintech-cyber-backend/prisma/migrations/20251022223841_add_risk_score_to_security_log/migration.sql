-- AlterTable
ALTER TABLE "SecurityLog" ADD COLUMN     "riskScore" INTEGER DEFAULT 0;
