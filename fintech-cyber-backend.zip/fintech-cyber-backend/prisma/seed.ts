// FINTECH-CYBER-BACKEND/prisma/seed.ts
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting data seeding...');

  // Clear existing data in correct order to avoid foreign key constraints
  console.log('🗑️  Clearing existing data...');
  await prisma.transactionMood.deleteMany();
  await prisma.securityLog.deleteMany();
  await prisma.securityEvent.deleteMany();
  await prisma.transaction.deleteMany();
  await prisma.recurringTransaction.deleteMany();
  await prisma.debt.deleteMany();
  await prisma.financialGoal.deleteMany();
  await prisma.budget.deleteMany();
  await prisma.account.deleteMany();
  await prisma.user.deleteMany();

  console.log('✅ Database cleared');

  // Create 2 users with enhanced security fields
  const hashedPassword = await bcrypt.hash('password123', 12);
  
  const user1 = await prisma.user.create({
    data: {
      email: 'john.doe@example.com',
      password: hashedPassword,
      name: 'John Doe',
      isVerified: true,
      alertEmailEnabled: true,
      typicalLoginHours: ['09:00-17:00'],
      knownIPs: ['192.168.1.100'],
      lastUserAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    },
  });

  const user2 = await prisma.user.create({
    data: {
      email: 'jane.smith@example.com',
      password: hashedPassword,
      name: 'Jane Smith',
      isVerified: true,
      alertEmailEnabled: true,
      typicalLoginHours: ['08:00-16:00'],
      knownIPs: ['192.168.1.101'],
      lastUserAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
    },
  });

  console.log('✅ Created users:', user1.email, user2.email);

  // Create accounts for both users
  const user1Account = await prisma.account.create({
    data: {
      userId: user1.id,
      name: 'Primary Checking',
      balance: 5000.00,
    },
  });

  const user1Savings = await prisma.account.create({
    data: {
      userId: user1.id,
      name: 'Savings Account',
      balance: 15000.00,
    },
  });

  const user2Account = await prisma.account.create({
    data: {
      userId: user2.id,
      name: 'Main Account',
      balance: 7500.00,
    },
  });

  console.log('✅ Created accounts');

  // Generate 3 months of realistic transaction data
  const categories = {
    income: ['Salary', 'Freelance', 'Investment', 'Bonus', 'Side Hustle'],
    expense: ['Food', 'Transport', 'Entertainment', 'Bills', 'Shopping', 'Healthcare', 'Education', 'Travel']
  };

  const users = [
    { user: user1, accounts: [user1Account, user1Savings] },
    { user: user2, accounts: [user2Account] }
  ];

  for (const { user, accounts } of users) {
    console.log(`📊 Generating data for ${user.name}...`);

    // Create budgets for each user
    for (const category of categories.expense) {
      await prisma.budget.create({
        data: {
          userId: user.id,
          category: category,
          limit: Math.floor(Math.random() * 1000) + 200,
          spent: 0,
          period: 'monthly',
          rolloverType: ['none', 'full', 'partial'][Math.floor(Math.random() * 3)] as any,
          rolloverAmount: Math.floor(Math.random() * 100),
          allowExceed: Math.random() > 0.7
        },
      });
    }

    // Create financial goals
    const goals = [
      { name: 'Emergency Fund', target: 10000, category: 'savings' },
      { name: 'Vacation to Europe', target: 5000, category: 'savings' },
      { name: 'New Car', target: 20000, category: 'savings' },
      { name: 'Home Down Payment', target: 50000, category: 'savings' }
    ];

    for (const goal of goals.slice(0, 2)) { // Create 2 goals per user
      await prisma.financialGoal.create({
        data: {
          userId: user.id,
          name: goal.name,
          targetAmount: goal.target,
          currentAmount: Math.floor(Math.random() * goal.target * 0.7),
          deadline: new Date(Date.now() + 180 * 24 * 60 * 60 * 1000), // 6 months from now
          category: goal.category,
          allocationPercentage: Math.floor(Math.random() * 20) + 5,
          isActive: true
        },
      });
    }

    // Generate 3 months of transactions
    const today = new Date();
    const transactionMoods = ['happy', 'stressed', 'bored', 'impulsive', 'planned', 'anxious', 'excited', 'regretful'];
    
    for (let monthOffset = 0; monthOffset < 3; monthOffset++) {
      const monthDate = new Date(today.getFullYear(), today.getMonth() - monthOffset, 1);
      
      // 25-40 transactions per month
      const transactionsCount = Math.floor(Math.random() * 16) + 25;
      
      for (let i = 0; i < transactionsCount; i++) {
        const transactionDate = new Date(
          monthDate.getFullYear(),
          monthDate.getMonth(),
          Math.floor(Math.random() * 28) + 1,
          Math.floor(Math.random() * 24), // Random hour
          Math.floor(Math.random() * 60)  // Random minute
        );

        const isIncome = Math.random() > 0.75; // 25% chance of income
        const account = accounts[Math.floor(Math.random() * accounts.length)];
        
        let amount: number, category: string, description: string;
        
        if (isIncome) {
          amount = Math.floor(Math.random() * 2000) + 1000; // Income: 1000-3000
          category = categories.income[Math.floor(Math.random() * categories.income.length)];
          description = `${category} payment`;
        } else {
          amount = -(Math.floor(Math.random() * 300) + 10); // Expense: 10-310 (negative)
          category = categories.expense[Math.floor(Math.random() * categories.expense.length)];
          const descriptions: { [key: string]: string[] } = {
            'Food': ['Restaurant dinner', 'Groceries', 'Coffee shop', 'Lunch with colleagues'],
            'Transport': ['Gas station', 'Public transport', 'Uber ride', 'Car maintenance'],
            'Entertainment': ['Movie tickets', 'Concert', 'Netflix subscription', 'Game purchase'],
            'Bills': ['Electricity bill', 'Internet bill', 'Water bill', 'Phone bill'],
            'Shopping': ['Clothing', 'Electronics', 'Home goods', 'Online shopping'],
            'Healthcare': ['Doctor visit', 'Pharmacy', 'Dental checkup', 'Health insurance'],
            'Education': ['Online course', 'Books', 'Workshop', 'Software subscription'],
            'Travel': ['Hotel booking', 'Flight tickets', 'Airbnb', 'Travel insurance']
          };
          description = descriptions[category] ? descriptions[category][Math.floor(Math.random() * descriptions[category].length)] : `${category} expense`;
        }

        const transaction = await prisma.transaction.create({
          data: {
            accountId: account.id,
            amount: amount,
            type: isIncome ? 'income' : 'expense',
            category: category,
            date: transactionDate,
            description: description,
            // Remove paymentMethod since it's not in your schema
            flagged: Math.random() > 0.95, // 5% chance of being flagged
            fraudReason: Math.random() > 0.95 ? 'Unusual spending pattern detected' : null,
            riskScore: Math.random() > 0.9 ? Math.floor(Math.random() * 40) + 60 : Math.floor(Math.random() * 30), // Higher risk if flagged
            reviewed: Math.random() > 0.9 // 10% chance of being reviewed
          },
        });

        // Add mood to 30% of transactions
        if (Math.random() > 0.7) {
          await prisma.transactionMood.create({
            data: {
              transactionId: transaction.id,
              userId: user.id,
              mood: transactionMoods[Math.floor(Math.random() * transactionMoods.length)] as any,
              intensity: Math.floor(Math.random() * 10) + 1,
              notes: Math.random() > 0.8 ? 'This was an impulse purchase' : null
            },
          });
        }
      }
    }

    // Create recurring transactions
    const recurringTemplates = [
      { description: 'Netflix Subscription', amount: -15.99, category: 'Entertainment', frequency: 'monthly' },
      { description: 'Gym Membership', amount: -49.99, category: 'Healthcare', frequency: 'monthly' },
      { description: 'Salary', amount: 4500.00, category: 'Salary', frequency: 'monthly' },
      { description: 'Spotify Premium', amount: -9.99, category: 'Entertainment', frequency: 'monthly' }
    ];

    for (const template of recurringTemplates.slice(0, 2)) { // Create 2 recurring per user
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() - 1); // Started last month
      
      await prisma.recurringTransaction.create({
        data: {
          userId: user.id,
          accountId: accounts[0].id,
          amount: Math.abs(template.amount),
          type: template.amount > 0 ? 'income' : 'expense',
          category: template.category,
          description: template.description,
          frequency: template.frequency as any,
          interval: 1,
          startDate: startDate,
          nextRunDate: new Date(startDate.getFullYear(), startDate.getMonth() + 1, startDate.getDate()),
          isActive: true,
          autoApprove: true,
          totalRuns: 1
        },
      });
    }

    // Create debts
    const debtTypes = [
      { name: 'Credit Card Debt', type: 'credit_card', principal: 5000, interest: 18.5, term: 36 },
      { name: 'Student Loan', type: 'loan', principal: 25000, interest: 5.5, term: 120 },
      { name: 'Car Loan', type: 'loan', principal: 15000, interest: 6.2, term: 60 }
    ];

    for (const debtType of debtTypes.slice(0, 2)) { // Create 2 debts per user
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() - 12); // Started 1 year ago
      
      await prisma.debt.create({
        data: {
          userId: user.id,
          name: debtType.name,
          type: debtType.type as any,
          principal: debtType.principal,
          balance: debtType.principal * (0.3 + Math.random() * 0.5), // 30-80% remaining
          interestRate: debtType.interest,
          minimumPayment: debtType.principal * 0.03, // 3% minimum payment
          startDate: startDate,
          dueDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000), // Due in 15 days
          termMonths: debtType.term,
          paymentsMade: Math.floor(Math.random() * 12) + 6, // 6-18 payments made
          lender: ['Chase Bank', 'Wells Fargo', 'Bank of America', 'Local Credit Union'][Math.floor(Math.random() * 4)],
          isActive: true
        },
      });
    }

    // Create security logs for login history
    const securityActions = ['login_success', 'login_failed', 'password_change', 'profile_update'];
    
    for (let i = 0; i < 20; i++) {
      const logDate = new Date();
      logDate.setDate(logDate.getDate() - Math.floor(Math.random() * 30)); // Random day in last 30 days
      
      await prisma.securityLog.create({
        data: {
          userId: user.id,
          action: securityActions[Math.floor(Math.random() * securityActions.length)],
          ipAddress: `192.168.1.${Math.floor(Math.random() * 255)}`,
          userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          timestamp: logDate,
          details: 'Regular security activity',
          riskScore: Math.floor(Math.random() * 20) // Low risk for most activities
        },
      });
    }

    // Create a couple of security events
    await prisma.securityEvent.create({
      data: {
        userId: user.id,
        type: 'suspicious_transaction',
        severity: 'medium',
        title: 'Unusual spending pattern detected',
        message: 'A transaction was flagged for exceeding typical spending limits',
        resolved: false
      },
    });

    console.log(`✅ Completed data generation for ${user.name}`);
  }

  console.log('🎉 Data seeding completed successfully!');
  console.log('');
  console.log('📋 SEEDED DATA SUMMARY:');
  console.log('   👥 2 users created');
  console.log('   💰 3 accounts created');
  console.log('   📊 16 budgets created (8 per user)');
  console.log('   🎯 4 financial goals created (2 per user)');
  console.log('   💳 150-240 transactions created (75-120 per user)');
  console.log('   🔄 4 recurring transactions created (2 per user)');
  console.log('   🏦 4 debts created (2 per user)');
  console.log('   🛡️  40 security logs created (20 per user)');
  console.log('   ⚠️  2 security events created (1 per user)');
  console.log('');
  console.log('🔑 TEST CREDENTIALS:');
  console.log('   User 1: john.doe@example.com / password123');
  console.log('   User 2: jane.smith@example.com / password123');
  console.log('');
  console.log('🚀 You can now start the backend server and test the application!');
}

main()
  .catch(e => {
    console.error('❌ Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });