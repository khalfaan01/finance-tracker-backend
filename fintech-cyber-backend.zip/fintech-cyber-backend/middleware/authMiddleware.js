import jwt from "jsonwebtoken";

// In-memory token blacklist (use Redis in production)
const tokenBlacklist = new Set();

export const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  console.log(' Auth Middleware Debug:'); // ADD THIS
  console.log('   - Authorization header:', authHeader ? 'PRESENT' : 'MISSING'); 
  console.log('   - Token extracted:', token ? `PRESENT (${token.substring(0, 20)}...)` : 'MISSING'); 
  console.log('   - JWT_SECRET exists:', process.env.JWT_SECRET ? 'YES' : 'NO'); 
  console.log('   - Request IP:', req.ip); 
  console.log('   - Request URL:', req.url); 

  if (!token) {
    console.log(' Auth Failed: No token provided'); 
    return res.status(401).json({ error: "Access token required" });
  }

  // Check if token is blacklisted
  if (tokenBlacklist.has(token)) {
    console.log(' Auth Failed: Token revoked'); 
    return res.status(403).json({ error: "Token revoked" });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      console.log(' Token verification failed:', err.message); 
      console.log('   - Error name:', err.name); 
      if (err.name === 'TokenExpiredError') {
        return res.status(403).json({ error: "Token expired" });
      }
      if (err.name === 'JsonWebTokenError') {
        console.log('   - Likely cause: JWT secret mismatch'); 
      }
      return res.status(403).json({ error: "Invalid token" });
    }

    console.log(' Token verified successfully:'); 
    console.log('   - User ID:', user.userId); 
    console.log('   - Token payload:', user); 
    
    req.user = user;

    // Log security event for authenticated requests
    console.log(` Authenticated request from user ${user.userId}, IP: ${req.ip}`);

    next();
  });
};

// Token revocation function
export const revokeToken = (token) => {
  tokenBlacklist.add(token);
  
  // Optional: Clean up old tokens periodically
  setTimeout(() => {
    tokenBlacklist.delete(token);
  }, 24 * 60 * 60 * 1000); // Remove after 24 hours
};

// Middleware to check user permissions
export const requireAdmin = (req, res, next) => {
  // This would check if user has admin role
  
  if (!req.user.isAdmin) {
    return res.status(403).json({ error: "Admin access required" });
  }
  next();
};