export class TransactionMood {
  constructor(data) {
    this.transactionId = data.transactionId;
    this.userId = data.userId;
    this.mood = data.mood;
    this.notes = data.notes;
    this.intensity = data.intensity || 5;
  }

  static validate(moodData) {
    const validMoods = ['happy', 'stressed', 'bored', 'impulsive', 'planned', 'anxious', 'excited', 'regretful'];
    
    if (!validMoods.includes(moodData.mood)) {
      throw new Error(`Invalid mood. Must be one of: ${validMoods.join(', ')}`);
    }
    
    if (moodData.intensity && (moodData.intensity < 1 || moodData.intensity > 10)) {
      throw new Error('Intensity must be between 1 and 10');
    }
    
    return true;
  }
}