export class RecurringTransaction {
  constructor(data) {
    this.userId = data.userId;
    this.accountId = data.accountId;
    this.amount = data.amount;
    this.type = data.type;
    this.category = data.category;
    this.description = data.description;
    this.frequency = data.frequency;
    this.interval = data.interval || 1;
    this.startDate = new Date(data.startDate);
    this.endDate = data.endDate ? new Date(data.endDate) : null;
    this.isActive = data.isActive !== false;
    this.autoApprove = data.autoApprove || false;
    this.nextRunDate = this.calculateNextRunDate();
  }

  static validate(recurringData) {
    const validFrequencies = ['daily', 'weekly', 'monthly', 'yearly'];
    
    if (!validFrequencies.includes(recurringData.frequency)) {
      throw new Error(`Invalid frequency. Must be one of: ${validFrequencies.join(', ')}`);
    }
    
    if (recurringData.amount <= 0) {
      throw new Error('Amount must be positive');
    }
    
    if (!['income', 'expense'].includes(recurringData.type)) {
      throw new Error('Type must be income or expense');
    }
    
    const startDate = new Date(recurringData.startDate);
    if (startDate < new Date()) {
      throw new Error('Start date cannot be in the past');
    }
    
    return true;
  }

  calculateNextRunDate() {
    const now = new Date();
    const start = new Date(this.startDate);
    
    if (start > now) {
      return start;
    }
    
    // For existing recurring transactions, calculate next run from now
    return this.addToDate(now, this.frequency, this.interval);
  }

  addToDate(date, frequency, interval) {
    const newDate = new Date(date);
    
    switch (frequency) {
      case 'daily':
        newDate.setDate(newDate.getDate() + interval);
        break;
      case 'weekly':
        newDate.setDate(newDate.getDate() + (7 * interval));
        break;
      case 'monthly':
        newDate.setMonth(newDate.getMonth() + interval);
        break;
      case 'yearly':
        newDate.setFullYear(newDate.getFullYear() + interval);
        break;
    }
    
    return newDate;
  }
}