import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { body, validationResult } from "express-validator";
import prisma from "../db.js";
import axios from "axios";
import { authenticateToken } from "../middleware/authMiddleware.js";

const router = express.Router();


// UTILITY FUNCTIONS


/**
 * Enhanced GeoIP function with multiple free services as fallback
 */
async function getGeoLocation(ip) {
  try {
    // Handle localhost and private IPs - default to Cape Town
    if (ip === '::1' || ip === '127.0.0.1' || ip.startsWith('192.168.') || ip.startsWith('10.') || ip.startsWith('172.')) {
      console.log(' Local/private IP detected, using Cape Town as default');
      return { 
        city: 'Cape Town', 
        country_name: 'South Africa', 
        country_code: 'ZA',
        region: 'Western Cape'
      };
    }

    // Try multiple free IP geolocation services
    const services = [
      `https://ipapi.co/${ip}/json/`,
      `https://ipwho.is/${ip}`,
      `http://ip-api.com/json/${ip}`
    ];

    for (const serviceUrl of services) {
      try {
        console.log(` Trying geolocation service: ${serviceUrl}`);
        const response = await axios.get(serviceUrl, { timeout: 5000 });
        
        if (serviceUrl.includes('ipapi.co')) {
          if (response.data && response.data.country_name) {
            console.log(' Success with ipapi.co:', response.data);
            return {
              city: response.data.city || 'Unknown',
              country_name: response.data.country_name,
              country_code: response.data.country_code,
              region: response.data.region
            };
          }
        } else if (serviceUrl.includes('ipwho.is')) {
          if (response.data && response.data.country) {
            console.log(' Success with ipwho.is:', response.data);
            return {
              city: response.data.city || 'Unknown',
              country_name: response.data.country,
              country_code: response.data.country_code,
              region: response.data.region
            };
          }
        } else if (serviceUrl.includes('ip-api.com')) {
          if (response.data && response.data.country) {
            console.log(' Success with ip-api.com:', response.data);
            return {
              city: response.data.city || 'Unknown',
              country_name: response.data.country,
              country_code: response.data.countryCode,
              region: response.data.regionName
            };
          }
        }
      } catch (serviceError) {
        console.log(` Service failed: ${serviceUrl}`, serviceError.message);
        continue; // Try next service
      }
    }

    throw new Error('All geolocation services failed');
    
  } catch (error) {
    console.log(' All geolocation services failed, using Cape Town as default');
    return { 
      city: 'Cape Town', 
      country_name: 'South Africa', 
      country_code: 'ZA',
      region: 'Western Cape'
    };
  }
}

/**
 * Check if account is locked
 */
async function checkAccountLock(user) {
  if (user.lockedUntil && user.lockedUntil > new Date()) {
    throw new Error('Account temporarily locked. Try again later.');
  }
}

/**
 * Log security event for login attempts
 */
async function logSecurityEvent(userId, action, ipAddress, details, riskScore = 0) {
  try {
    await prisma.securityLog.create({
      data: {
        userId,
        action,
        ipAddress,
        details,
        riskScore,
        timestamp: new Date()
      }
    });
  } catch (error) {
    console.error(' Failed to log security event:', error);
  }
}


// VALIDATION RULES


const registerValidation = [
  body("email").isEmail().withMessage("Please provide a valid email"),
  body("password")
    .isLength({ min: 8 }).withMessage("Password must be at least 8 characters")
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage("Password must contain uppercase, lowercase, and numbers"),
  body("name").optional().isLength({ min: 2 }).withMessage("Name must be at least 2 characters")
];

const loginValidation = [
  body("email").isEmail().withMessage("Please provide a valid email"),
  body("password").notEmpty().withMessage("Password is required")
];


// ROUTE HANDLERS


/**
 * REGISTER USER - ENHANCED PASSWORD POLICY
 */
router.post("/register", registerValidation, async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { email, password, name } = req.body;
  const normalizedEmail = email.toLowerCase().trim();

  try {
    // Check if user exists
    const existingUser = await prisma.user.findUnique({ 
      where: { email: normalizedEmail } 
    });
    
    if (existingUser) {
      return res.status(400).json({ 
        errors: [{ msg: "Email already registered" }] 
      });
    }

    // Hash password
    const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS) || 12;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Create user with default account
    const user = await prisma.user.create({
      data: {
        email: normalizedEmail,
        password: hashedPassword,
        name: name || null,
        accounts: {
          create: {
            name: "Main Account",
            balance: 0,
          },
        },
      },
      include: { accounts: true },
    });

    res.status(201).json({
      message: "User registered successfully",
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        accounts: user.accounts,
      },
    });
  } catch (error) {
    console.error(" Register error:", error);
    res.status(500).json({ 
      errors: [{ msg: "Server error during registration" }] 
    });
  }
});

/**
 * LOGIN USER - ENHANCED SECURITY
 */
router.post("/login", loginValidation, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { email, password } = req.body;
  const normalizedEmail = email.toLowerCase().trim();

  try {
    console.log('🔍 Looking for user (case-insensitive):', normalizedEmail);
    
    // Case-insensitive search
    const allUsers = await prisma.user.findMany();
    const user = allUsers.find(u => u.email.toLowerCase() === normalizedEmail);
    
    console.log('🔍 User found:', user ? `YES - ${user.email}` : 'NO');

    if (!user) {
      console.log(' User not found for email:', normalizedEmail);
      return res.status(400).json({ message: "Invalid credentials" });
    }

    // Check account lock
    try {
      await checkAccountLock(user);
    } catch (lockError) {
      return res.status(423).json({ message: lockError.message });
    }

    // Validate password
    console.log(' Comparing passwords...');
    const valid = await bcrypt.compare(password, user.password);
    console.log(' Password valid:', valid);

    if (!valid) {
      // Handle failed login
      const loginAttempts = (user.loginAttempts || 0) + 1;
      let lockedUntil = null;
      
      if (loginAttempts >= 5) {
        lockedUntil = new Date(Date.now() + 15 * 60 * 1000);
      }

      await prisma.user.update({
        where: { id: user.id },
        data: { loginAttempts, lockedUntil }
      });

      // Log failed attempt
      const clientIP = req.ip || req.connection.remoteAddress;
      await logSecurityEvent(
        user.id, 
        'login_failed', 
        clientIP, 
        `Failed login attempt ${loginAttempts}/5`, 
        20
      );

      console.log(' Password comparison failed');
      return res.status(400).json({ 
        message: "Invalid credentials",
        remainingAttempts: 5 - loginAttempts
      });
    }

    // SUCCESSFUL LOGIN

    // Reset login attempts
    await prisma.user.update({
      where: { id: user.id },
      data: { loginAttempts: 0, lockedUntil: null }
    });

    // Get geolocation data
    const clientIP = req.ip || req.connection.remoteAddress;
    const geoData = await getGeoLocation(clientIP);

    // Update user with login location
    await prisma.user.update({
      where: { id: user.id },
      data: {
        lastLogin: new Date(),
        lastLoginIP: clientIP,
        lastLoginCity: geoData.city,
        lastLoginCountry: geoData.country_name,
      },
    });

    // Log successful login
    await logSecurityEvent(
      user.id,
      'login_success',
      clientIP,
      `Successful login from ${geoData.city}, ${geoData.country_name}`,
      0
    );

    // Generate JWT tokens
    const accessToken = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, {
      expiresIn: "15m",
    });

    const refreshToken = jwt.sign({ userId: user.id }, process.env.JWT_SECRET + user.password, {
      expiresIn: "7d",
    });

    res.json({
      message: "Login successful",
      accessToken,
      refreshToken,
      user: { 
        id: user.id, 
        email: user.email,
        lastLoginFrom: `${geoData.city}, ${geoData.country_name}`
      },
    });

  } catch (error) {
    console.error(" Login error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

/**
 * REFRESH TOKEN ENDPOINT
 */
router.post("/refresh", async (req, res) => {
  const { refreshToken } = req.body;
  
  if (!refreshToken) {
    return res.status(401).json({ message: "Refresh token required" });
  }

  try {
    const decoded = jwt.decode(refreshToken);
    if (!decoded) {
      return res.status(403).json({ message: "Invalid token" });
    }

    const user = await prisma.user.findUnique({ where: { id: decoded.userId } });
    if (!user) {
      return res.status(403).json({ message: "User not found" });
    }

    // Verify with user-specific secret
    jwt.verify(refreshToken, process.env.JWT_SECRET + user.password);

    const newAccessToken = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, {
      expiresIn: "15m",
    });

    res.json({ accessToken: newAccessToken });
  } catch (error) {
    console.error(" Token refresh error:", error);
    res.status(403).json({ message: "Invalid refresh token" });
  }
});

/**
 * LOGOUT ENDPOINT
 */
router.post("/logout", authenticateToken, async (req, res) => {
  res.json({ message: "Logged out successfully" });
});


// DEBUG/UTILITY ROUTES


/**
 * DEBUG ROUTE - Get all users (for development only)
 */
router.get("/debug-all-users", async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      select: { 
        id: true, 
        email: true, 
        createdAt: true,
        lastLogin: true 
      }
    });
    console.log(' EXACT USER DATA IN DATABASE:');
    users.forEach(user => {
      console.log(`   ID: ${user.id}, Email: "${user.email}", Created: ${user.createdAt}`);
    });
    res.json(users);
  } catch (error) {
    console.error(' Error fetching users:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

export { router as default };