import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";
import { body, validationResult } from "express-validator";
import prisma from "../db.js";
// Remove the model import since we're using Prisma directly
// import { TransactionMood } from "../models/TransactionMood.js";

const router = express.Router();

// Validation rules for mood tracking
const moodValidation = [
  body("transactionId").isInt({ min: 1 }).withMessage("Valid transaction ID required"),
  body("mood").isIn(['happy', 'stressed', 'bored', 'impulsive', 'planned', 'anxious', 'excited', 'regretful'])
    .withMessage("Valid mood required"),
  body("intensity").optional().isInt({ min: 1, max: 10 }).withMessage("Intensity must be 1-10"),
  body("notes").optional().trim().escape().isLength({ max: 500 }).withMessage("Notes too long")
];

// Add mood to transaction
router.post("/", authenticateToken, moodValidation, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { transactionId, mood, intensity, notes } = req.body;

  try {
    // Verify transaction belongs to user
    const transaction = await prisma.transaction.findFirst({
      where: {
        id: parseInt(transactionId),
        account: {
          userId: req.user.userId
        }
      }
    });

    if (!transaction) {
      return res.status(404).json({ error: "Transaction not found" });
    }

    // Create or update mood
    const transactionMood = await prisma.transactionMood.upsert({
      where: {
        transactionId: parseInt(transactionId)
      },
      update: {
        mood,
        intensity: intensity || 5,
        notes: notes || null
      },
      create: {
        transactionId: parseInt(transactionId),
        userId: req.user.userId,
        mood,
        intensity: intensity || 5,
        notes: notes || null
      }
    });

    res.status(201).json(transactionMood);
  } catch (error) {
    console.error("Mood creation error:", error);
    res.status(500).json({ error: "Failed to add mood to transaction" });
  }
});

// Get moods for user with analysis
router.get("/analysis", authenticateToken, async (req, res) => {
  try {
    const moods = await prisma.transactionMood.findMany({
      where: {
        userId: req.user.userId
      },
      include: {
        transaction: {
          include: {
            account: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    // Basic analysis
    const moodAnalysis = {
      totalTracked: moods.length,
      moodDistribution: {},
      averageSpendingByMood: {},
      commonPatterns: []
    };

    // Calculate mood distribution and spending patterns
    moods.forEach(mood => {
      const amount = Math.abs(mood.transaction.amount);
      
      // Mood distribution
      moodAnalysis.moodDistribution[mood.mood] = 
        (moodAnalysis.moodDistribution[mood.mood] || 0) + 1;
      
      // Average spending by mood
      if (!moodAnalysis.averageSpendingByMood[mood.mood]) {
        moodAnalysis.averageSpendingByMood[mood.mood] = {
          total: 0,
          count: 0,
          average: 0
        };
      }
      moodAnalysis.averageSpendingByMood[mood.mood].total += amount;
      moodAnalysis.averageSpendingByMood[mood.mood].count += 1;
    });

    // Calculate averages
    Object.keys(moodAnalysis.averageSpendingByMood).forEach(mood => {
      const data = moodAnalysis.averageSpendingByMood[mood];
      data.average = data.total / data.count;
    });

    res.json({
      moods,
      analysis: moodAnalysis
    });
  } catch (error) {
    console.error("Mood analysis error:", error);
    res.status(500).json({ error: "Failed to analyze moods" });
  }
});

// Get mood by transaction ID
router.get("/transaction/:transactionId", authenticateToken, async (req, res) => {
  const { transactionId } = req.params;

  try {
    const mood = await prisma.transactionMood.findFirst({
      where: {
        transactionId: parseInt(transactionId),
        userId: req.user.userId
      }
    });

    res.json(mood || null);
  } catch (error) {
    console.error("Get mood error:", error);
    res.status(500).json({ error: "Failed to get mood" });
  }
});

export default router;