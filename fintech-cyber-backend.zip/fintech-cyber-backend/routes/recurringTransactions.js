import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";
import { body, validationResult } from "express-validator";
import prisma from "../db.js";

const router = express.Router();

// Validation rules for recurring transactions
const recurringValidation = [
  body("accountId").isInt({ min: 1 }).withMessage("Valid account ID required"),
  body("amount").isFloat({ min: 0.01 }).withMessage("Amount must be positive"),
  body("type").isIn(["income", "expense"]).withMessage("Type must be income or expense"),
  body("category").trim().escape().isLength({ min: 1, max: 50 }),
  body("description").optional().trim().escape().isLength({ max: 255 }),
  body("frequency").isIn(["daily", "weekly", "monthly", "yearly"]),
  body("interval").optional().isInt({ min: 1, max: 365 }),
  body("startDate").isISO8601(),
  body("endDate").optional().isISO8601(),
  body("autoApprove").optional().isBoolean()
];

// Get all recurring transactions for user
router.get("/", authenticateToken, async (req, res) => {
  try {
    const recurringTransactions = await prisma.recurringTransaction.findMany({
      where: {
        userId: req.user.userId
      },
      include: {
        account: true
      },
      orderBy: {
        nextRunDate: 'asc'
      }
    });

    res.json(recurringTransactions);
  } catch (error) {
    console.error("Get recurring transactions error:", error);
    res.status(500).json({ error: "Failed to fetch recurring transactions" });
  }
});

// Create new recurring transaction
router.post("/", authenticateToken, recurringValidation, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const {
    accountId,
    amount,
    type,
    category,
    description,
    frequency,
    interval = 1,
    startDate,
    endDate,
    autoApprove = false
  } = req.body;

  try {
    // Verify account belongs to user
    const account = await prisma.account.findFirst({
      where: {
        id: parseInt(accountId),
        userId: req.user.userId
      }
    });

    if (!account) {
      return res.status(404).json({ error: "Account not found" });
    }

    const recurringData = {
      userId: req.user.userId,
      accountId: parseInt(accountId),
      amount: parseFloat(amount),
      type,
      category: category.trim(),
      description: description ? description.trim() : null,
      frequency,
      interval: parseInt(interval),
      startDate: new Date(startDate),
      endDate: endDate ? new Date(endDate) : null,
      autoApprove,
      nextRunDate: new Date(startDate)
    };

    // Basic validation
    const validFrequencies = ['daily', 'weekly', 'monthly', 'yearly'];
    if (!validFrequencies.includes(recurringData.frequency)) {
      return res.status(400).json({ error: `Invalid frequency. Must be one of: ${validFrequencies.join(', ')}` });
    }

    if (recurringData.amount <= 0) {
      return res.status(400).json({ error: 'Amount must be positive' });
    }

    const startDateObj = new Date(recurringData.startDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Allow today's date and future dates
    if (startDateObj < today) {
      return res.status(400).json({ error: 'Start date cannot be in the past' });
    }

    const recurringTransaction = await prisma.recurringTransaction.create({
      data: recurringData
    });

    res.status(201).json(recurringTransaction);
  } catch (error) {
    console.error("Create recurring transaction error:", error);
    res.status(400).json({ error: error.message });
  }
});

// PUT update recurring transaction (for pausing/activating)
router.put("/:id", authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    // Verify the recurring transaction belongs to the user
    const existingTransaction = await prisma.recurringTransaction.findFirst({
      where: {
        id: parseInt(id),
        userId: req.user.userId
      }
    });

    if (!existingTransaction) {
      return res.status(404).json({ error: "Recurring transaction not found" });
    }

    // Only allow updating specific fields for security
    const allowedUpdates = ['isActive', 'amount', 'category', 'description', 'frequency', 'endDate'];
    const filteredUpdates = {};
    
    Object.keys(updates).forEach(key => {
      if (allowedUpdates.includes(key)) {
        filteredUpdates[key] = updates[key];
      }
    });

    // Update the transaction
    const updatedTransaction = await prisma.recurringTransaction.update({
      where: { id: parseInt(id) },
      data: {
        ...filteredUpdates,
        updatedAt: new Date()
      }
    });

    res.json(updatedTransaction);
  } catch (error) {
    console.error("Update recurring transaction error:", error);
    res.status(400).json({ error: "Failed to update recurring transaction" });
  }
});

// DELETE recurring transaction
router.delete("/:id", authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    // Verify the recurring transaction belongs to the user
    const existingTransaction = await prisma.recurringTransaction.findFirst({
      where: {
        id: parseInt(id),
        userId: req.user.userId
      }
    });

    if (!existingTransaction) {
      return res.status(404).json({ error: "Recurring transaction not found" });
    }

    // Delete the recurring transaction
    await prisma.recurringTransaction.delete({
      where: { id: parseInt(id) }
    });

    res.json({ message: "Recurring transaction deleted successfully" });
  } catch (error) {
    console.error("Delete recurring transaction error:", error);
    res.status(400).json({ error: "Failed to delete recurring transaction" });
  }
});

// Process due recurring transactions (admin/background task)
router.post("/process-due", authenticateToken, async (req, res) => {
  try {
    const now = new Date();
    const dueTransactions = await prisma.recurringTransaction.findMany({
      where: {
        userId: req.user.userId,
        isActive: true,
        nextRunDate: {
          lte: now
        },
        OR: [
          { endDate: null },
          { endDate: { gte: now } }
        ]
      },
      include: {
        account: true
      }
    });

    const results = [];

    for (const recurring of dueTransactions) {
      try {
        // Create the transaction
        const transactionData = {
          accountId: recurring.accountId,
          amount: recurring.type === 'expense' ? -Math.abs(recurring.amount) : Math.abs(recurring.amount),
          type: recurring.type,
          category: recurring.category,
          description: recurring.description,
          date: new Date(),
          isRecurring: true,
          recurringTransactionId: recurring.id
        };

        const transaction = await prisma.transaction.create({
          data: transactionData
        });

        // Update recurring transaction
        const nextRunDate = calculateNextRunDate(recurring, now);
        
        await prisma.recurringTransaction.update({
          where: { id: recurring.id },
          data: {
            lastRun: new Date(),
            nextRunDate,
            totalRuns: { increment: 1 }
          }
        });

        results.push({
          recurringId: recurring.id,
          transactionId: transaction.id,
          status: 'success',
          amount: transaction.amount,
          description: transaction.description
        });

      } catch (error) {
        results.push({
          recurringId: recurring.id,
          status: 'error',
          error: error.message
        });
      }
    }

    res.json({
      processed: results.length,
      results
    });
  } catch (error) {
    console.error("Process due transactions error:", error);
    res.status(500).json({ error: "Failed to process recurring transactions" });
  }
});

// Helper function to calculate next run date
function calculateNextRunDate(recurring, fromDate) {
  const date = new Date(fromDate);
  
  switch (recurring.frequency) {
    case 'daily':
      date.setDate(date.getDate() + recurring.interval);
      break;
    case 'weekly':
      date.setDate(date.getDate() + (7 * recurring.interval));
      break;
    case 'monthly':
      date.setMonth(date.getMonth() + recurring.interval);
      break;
    case 'yearly':
      date.setFullYear(date.getFullYear() + recurring.interval);
      break;
  }
  
  return date;
}

export default router;