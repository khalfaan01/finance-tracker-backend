import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";
import prisma from "../db.js";

const router = express.Router();

// Get all budgets for the logged-in user
router.get("/", authenticateToken, async (req, res) => {
  try {
    const budgets = await prisma.budget.findMany({
      where: {
        userId: req.user.userId
      },
      orderBy: {
        createdAt: 'desc'
      }
    });
    res.json(budgets);
  } catch (error) {
    console.error("Failed to fetch budgets:", error);
    res.status(500).json({ error: "Failed to fetch budgets" });
  }
});

// Create a new budget with enhanced fields
router.post("/", authenticateToken, async (req, res) => {
  const { 
    category, 
    limit, 
    period, 
    rolloverType = "none", 
    rolloverAmount = 0, 
    allowExceed = false 
  } = req.body;
  
  try {
    const budget = await prisma.budget.create({
      data: {
        userId: req.user.userId,
        category,
        limit: parseFloat(limit),
        period: period || 'monthly',
        spent: 0,
        rolloverType,
        rolloverAmount: parseFloat(rolloverAmount),
        allowExceed
      }
    });
    
    res.status(201).json(budget);
  } catch (error) {
    console.error("Budget creation error:", error);
    res.status(500).json({ error: "Failed to create budget" });
  }
});

// Update budget
router.put("/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { 
    category, 
    limit, 
    period, 
    rolloverType, 
    rolloverAmount, 
    allowExceed,
    isActive 
  } = req.body;
  
  try {
    const budget = await prisma.budget.update({
      where: { 
        id: parseInt(id),
        userId: req.user.userId
      },
      data: {
        category,
        limit: parseFloat(limit),
        period,
        rolloverType,
        rolloverAmount: parseFloat(rolloverAmount),
        allowExceed,
        isActive
      }
    });
    
    res.json(budget);
  } catch (error) {
    console.error("Budget update error:", error);
    res.status(500).json({ error: "Failed to update budget" });
  }
});

// Delete budget
router.delete("/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;
  
  try {
    await prisma.budget.delete({
      where: { 
        id: parseInt(id),
        userId: req.user.userId
      }
    });
    
    res.json({ message: "Budget deleted successfully" });
  } catch (error) {
    console.error("Budget deletion error:", error);
    res.status(500).json({ error: "Failed to delete budget" });
  }
});

// Calculate rollover for a budget
router.post("/:id/calculate-rollover", authenticateToken, async (req, res) => {
  const { id } = req.params;
  
  try {
    const budget = await prisma.budget.findFirst({
      where: { 
        id: parseInt(id),
        userId: req.user.userId
      }
    });
    
    if (!budget) {
      return res.status(404).json({ error: "Budget not found" });
    }
    
    const unusedAmount = budget.limit - budget.spent;
    let rollover = 0;
    
    switch (budget.rolloverType) {
      case "full":
        rollover = Math.max(0, unusedAmount);
        break;
      case "partial":
        rollover = Math.max(0, unusedAmount * (budget.rolloverAmount / 100));
        break;
      case "capped":
        rollover = Math.min(Math.max(0, unusedAmount), budget.rolloverAmount);
        break;
      default: // "none"
        rollover = 0;
    }
    
    res.json({
      currentLimit: budget.limit,
      spent: budget.spent,
      unusedAmount,
      rolloverType: budget.rolloverType,
      rolloverAmount: budget.rolloverAmount,
      calculatedRollover: rollover,
      newLimit: budget.limit + rollover
    });
    
  } catch (error) {
    console.error("Rollover calculation error:", error);
    res.status(500).json({ error: "Failed to calculate rollover" });
  }
});

export { router as default };