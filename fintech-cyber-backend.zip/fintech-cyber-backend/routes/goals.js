import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";
import prisma from "../db.js";

const router = express.Router();

// Get all goals for the logged-in user
router.get("/", authenticateToken, async (req, res) => {
  try {
    const goals = await prisma.financialGoal.findMany({
      where: {
        userId: req.user.userId
      },
      orderBy: {
        deadline: 'asc'
      }
    });
    res.json(goals);
  } catch (error) {
    console.error("Failed to fetch goals:", error);
    res.status(500).json({ error: "Failed to fetch goals" });
  }
});

// Create a new goal with enhanced fields
router.post("/", authenticateToken, async (req, res) => {
  const { 
    name, 
    targetAmount, 
    currentAmount = 0, 
    deadline, 
    category = "savings",
    allocationPercentage = null 
  } = req.body;
  
  try {
    const goal = await prisma.financialGoal.create({
      data: {
        userId: req.user.userId,
        name,
        targetAmount: parseFloat(targetAmount),
        currentAmount: parseFloat(currentAmount),
        deadline: new Date(deadline),
        category,
        allocationPercentage: allocationPercentage ? parseFloat(allocationPercentage) : null,
        isCompleted: parseFloat(currentAmount) >= parseFloat(targetAmount)
      }
    });
    
    res.status(201).json(goal);
  } catch (error) {
    console.error("Goal creation error:", error);
    res.status(500).json({ error: "Failed to create goal" });
  }
});

// Update goal
router.put("/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { 
    name, 
    targetAmount, 
    currentAmount, 
    deadline, 
    category,
    allocationPercentage,
    isActive 
  } = req.body;
  
  try {
    // First get the current goal to handle partial updates
    const currentGoal = await prisma.financialGoal.findFirst({
      where: { 
        id: parseInt(id),
        userId: req.user.userId
      }
    });
    
    if (!currentGoal) {
      return res.status(404).json({ error: "Goal not found" });
    }
    
    // Use existing values if not provided in update
    const currentAmountNum = currentAmount !== undefined ? parseFloat(currentAmount) : currentGoal.currentAmount;
    const targetAmountNum = targetAmount !== undefined ? parseFloat(targetAmount) : currentGoal.targetAmount;
    
    const updateData = {
      name: name !== undefined ? name : currentGoal.name,
      targetAmount: targetAmountNum,
      currentAmount: currentAmountNum,
      deadline: deadline !== undefined ? new Date(deadline) : currentGoal.deadline,
      category: category !== undefined ? category : currentGoal.category,
      allocationPercentage: allocationPercentage !== undefined ? 
        (allocationPercentage ? parseFloat(allocationPercentage) : null) : 
        currentGoal.allocationPercentage,
      isActive: isActive !== undefined ? isActive : currentGoal.isActive,
      isCompleted: currentAmountNum >= targetAmountNum,
      completedAt: currentAmountNum >= targetAmountNum ? new Date() : null
    };
    
    const goal = await prisma.financialGoal.update({
      where: { 
        id: parseInt(id),
        userId: req.user.userId
      },
      data: updateData
    });
    
    res.json(goal);
  } catch (error) {
    console.error("Goal update error:", error);
    res.status(500).json({ error: "Failed to update goal" });
  }
});

// Delete goal
router.delete("/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;
  
  try {
    await prisma.financialGoal.delete({
      where: { 
        id: parseInt(id),
        userId: req.user.userId
      }
    });
    
    res.json({ message: "Goal deleted successfully" });
  } catch (error) {
    console.error("Goal deletion error:", error);
    res.status(500).json({ error: "Failed to delete goal" });
  }
});

// Manual contribution to goal
router.post("/:id/contribute", authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { amount, description = "Manual contribution" } = req.body;
  
  try {
    // Find user's account first
    const account = await prisma.account.findFirst({
      where: { 
        userId: req.user.userId 
      }
    });
    
    if (!account) {
      return res.status(404).json({ error: "No account found for user" });
    }

    const goal = await prisma.financialGoal.findFirst({
      where: { 
        id: parseInt(id),
        userId: req.user.userId
      }
    });
    
    if (!goal) {
      return res.status(404).json({ error: "Goal not found" });
    }
    
    const newAmount = goal.currentAmount + parseFloat(amount);
    const isCompleted = newAmount >= goal.targetAmount;
    
    const updatedGoal = await prisma.financialGoal.update({
      where: { 
        id: parseInt(id),
        userId: req.user.userId
      },
      data: {
        currentAmount: newAmount,
        isCompleted,
        completedAt: isCompleted ? new Date() : null
      }
    });
    
    // Create a transaction record for the contribution
    await prisma.transaction.create({
      data: {
        accountId: account.id,
        amount: parseFloat(amount),
        type: 'income',
        category: 'Goal Contribution',
        date: new Date(),
        description: `${description} - ${goal.name}`
      }
    });
    
    res.json({
      goal: updatedGoal,
      contribution: amount,
      previousAmount: goal.currentAmount,
      newAmount: newAmount,
      isCompleted
    });
    
  } catch (error) {
    console.error("Goal contribution error:", error);
    res.status(500).json({ error: "Failed to contribute to goal" });
  }
});

// Auto-allocate income to goals
router.post("/auto-allocate", authenticateToken, async (req, res) => {
  const { incomeAmount, incomeDescription = "Income allocation" } = req.body;
  
  try {
    // Find user's account first
    const account = await prisma.account.findFirst({
      where: { 
        userId: req.user.userId 
      }
    });
    
    if (!account) {
      return res.status(404).json({ error: "No account found for user" });
    }

    const activeGoals = await prisma.financialGoal.findMany({
      where: { 
        userId: req.user.userId,
        isActive: true,
        isCompleted: false,
        allocationPercentage: { not: null }
      }
    });
    
     // allocationPercentage
    const totalAllocation = activeGoals.reduce((sum, goal) => sum + (goal.allocationPercentage || 0), 0);
    
    if (totalAllocation > 100) {
      return res.status(400).json({ error: "Total allocation percentage exceeds 100%" });
    }
    
    const allocations = [];
    
    for (const goal of activeGoals) {
      const allocationAmount = (incomeAmount * goal.allocationPercentage) / 100;
      const newAmount = goal.currentAmount + allocationAmount;
      const isCompleted = newAmount >= goal.targetAmount;
      
      const updatedGoal = await prisma.financialGoal.update({
        where: { id: goal.id },
        data: {
          currentAmount: newAmount,
          isCompleted,
          completedAt: isCompleted ? new Date() : null
        }
      });
      
      // Create transaction for allocation
      await prisma.transaction.create({
        data: {
          accountId: account.id,
          amount: allocationAmount,
          type: 'income',
          category: 'Goal Allocation',
          date: new Date(),
          description: `${incomeDescription} - ${goal.name} (${goal.allocationPercentage}%)`
        }
      });
      
      allocations.push({
        goal: goal.name,
        allocationPercentage: goal.allocationPercentage,
        amount: allocationAmount,
        previousAmount: goal.currentAmount,
        newAmount: newAmount,
        isCompleted
      });
    }
    
    res.json({
      totalIncome: incomeAmount,
      totalAllocated: allocations.reduce((sum, alloc) => sum + alloc.amount, 0),
      allocations
    });
    
  } catch (error) {
    console.error("Auto-allocation error:", error);
    res.status(500).json({ error: "Failed to auto-allocate income" });
  }
});

export { router as default };