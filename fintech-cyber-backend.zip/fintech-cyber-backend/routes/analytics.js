import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";
import prisma from "../db.js";
import { AnalyticsService } from "../services/analyticsService.js";

const router = express.Router();

// Get comprehensive analytics for dashboard
router.get("/overview", authenticateToken, async (req, res) => {
  try {
    const analysis = await AnalyticsService.getComprehensiveAnalysis(req.user.userId, prisma);
    res.json(analysis);
  } catch (error) {
    console.error("Analytics error:", error);
    res.status(500).json({ error: "Failed to generate analytics" });
  }
});

// ENHANCED: Comprehensive Analytics Dashboard
router.get("/enhanced", authenticateToken, async (req, res) => {
  try {
    const { timeframe = 'monthly' } = req.query;
    
    const comprehensiveAnalysis = await AnalyticsService.getEnhancedComprehensiveAnalysis(
      req.user.userId, 
      prisma,
      timeframe
    );
    res.json(comprehensiveAnalysis);
  } catch (error) {
    console.error("Enhanced analytics error:", error);
    res.status(500).json({ error: "Failed to generate enhanced analytics" });
  }
});

// ENHANCED: Cash Flow Analysis
router.get("/cash-flow", authenticateToken, async (req, res) => {
  try {
    const { granularity = 'daily' } = req.query;
    const transactions = await prisma.transaction.findMany({
      where: { account: { userId: req.user.userId } },
      include: { account: true }
    });

    const cashFlowAnalysis = AnalyticsService.analyzeCashFlow(
      transactions, 
      granularity,
      req.user.userId
    );
    res.json(cashFlowAnalysis);
  } catch (error) {
    console.error("Cash flow analysis error:", error);
    res.status(500).json({ error: "Failed to analyze cash flow" });
  }
});

// ENHANCED: Income Stream Breakdown
router.get("/income-breakdown", authenticateToken, async (req, res) => {
  try {
    const transactions = await prisma.transaction.findMany({
      where: { 
        account: { userId: req.user.userId },
        type: 'income'
      },
      include: { account: true }
    });

    const incomeBreakdown = AnalyticsService.analyzeIncomeStreams(transactions);
    res.json(incomeBreakdown);
  } catch (error) {
    console.error("Income breakdown error:", error);
    res.status(500).json({ error: "Failed to analyze income streams" });
  }
});

// ENHANCED: Predictive Forecasting
router.get("/forecast", authenticateToken, async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const transactions = await prisma.transaction.findMany({
      where: { account: { userId: req.user.userId } },
      include: { account: true }
    });

    const forecast = AnalyticsService.generateSpendingForecast(transactions, parseInt(days));
    res.json(forecast);
  } catch (error) {
    console.error("Forecasting error:", error);
    res.status(500).json({ error: "Failed to generate forecast" });
  }
});

// ENHANCED: Contextual Spending Insights
router.get("/contextual-insights", authenticateToken, async (req, res) => {
  try {
    const transactions = await prisma.transaction.findMany({
      where: { account: { userId: req.user.userId } },
      include: { account: true }
    });

    const insights = AnalyticsService.generateContextualInsights(transactions);
    res.json(insights);
  } catch (error) {
    console.error("Contextual insights error:", error);
    res.status(500).json({ error: "Failed to generate contextual insights" });
  }
});

export default router;