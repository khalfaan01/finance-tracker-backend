import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";
import { body, validationResult } from "express-validator"; 
import prisma from "../db.js";

const router = express.Router();

// Input validation rules
const transactionValidation = [
  body("amount").isFloat({ min: 0.01 }).withMessage("Amount must be a positive number"),
  body("type").isIn(["income", "expense"]).withMessage("Type must be income or expense"),
  body("category").trim().escape().isLength({ min: 1, max: 50 }).withMessage("Category must be between 1-50 characters"),
  body("description").optional().trim().escape().isLength({ max: 255 }).withMessage("Description too long"),
  body("date").isISO8601().withMessage("Valid date required")
    .custom((value) => {
      const transactionDate = new Date(value);
      const today = new Date();
      today.setHours(23, 59, 59, 999); // End of today
      
      // Disallow future dates
      if (transactionDate > today) {
        throw new Error('Future dates are not allowed');
      }
      return true;
    })
];

// Helper function for fraud detection
async function calculateAverageTransaction(userId) {
  console.log(' Calculating average for user:', userId);
  
  const transactions = await prisma.transaction.findMany({
    where: { 
      account: { userId: userId },
      type: 'expense'
    }
  });
  
  if (transactions.length === 0) {
    return 100;
  }
  
  const total = transactions.reduce((sum, tx) => sum + Math.abs(tx.amount), 0);
  const average = total / transactions.length;
  
  return average;
}

// Get all transactions for the logged-in user
router.get("/", authenticateToken, async (req, res) => {
  try {
    const transactions = await prisma.transaction.findMany({
      where: {
        account: {
          userId: req.user.userId
        }
      },
      include: {
        account: true
      },
      orderBy: {
        date: 'desc'
      }
    });
    res.json(transactions);
  } catch (error) {
    console.error("Failed to fetch transactions:", error);
    res.status(500).json({ error: "Failed to fetch transactions" });
  }
});

// Create a new transaction WITH INPUT VALIDATION
router.post("/", authenticateToken, transactionValidation, async (req, res) => {
  // Check validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { amount, type, category, date, description } = req.body;
  
  console.log(' New transaction received:', { amount, type, category, date, description });
  
  try {
    // Additional server-side date validation
    const transactionDate = new Date(date);
    const today = new Date();
    today.setHours(23, 59, 59, 999); // End of today
    
    if (transactionDate > today) {
      return res.status(400).json({ 
        error: "Future dates are not allowed. Please select today or a past date." 
      });
    }

    // Auto-find the user's first account
    const account = await prisma.account.findFirst({
      where: { 
        userId: req.user.userId 
      }
    });
    
    if (!account) {
      return res.status(404).json({ error: "No account found for user" });
    }


    const accountId = account.id;
    
    let fraudDetected = false;
    let fraudReason = '';
    let riskScore = 0;

    // BUDGET ENFORCEMENT CHECK 
    if (type === 'expense') {
      const budget = await prisma.budget.findFirst({
        where: { 
          userId: req.user.userId,
          category: category,
          isActive: true
        }
      });
      
      if (budget) {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
        const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        
        const currentSpending = await prisma.transaction.aggregate({
          where: {
            account: { userId: req.user.userId },
            type: 'expense',
            category: category,
            date: {
              gte: startOfMonth,
              lte: endOfMonth
            }
          },
          _sum: {
            amount: true
          }
        });
        
        const currentSpent = Math.abs(currentSpending._sum.amount || 0);
        const transactionAmount = Math.abs(amount);
        const wouldBeTotal = currentSpent + transactionAmount;
        
        if (wouldBeTotal > budget.limit) {
          const overspendAmount = wouldBeTotal - budget.limit;
          
          if (!budget.allowExceed) {
            return res.status(400).json({
              error: "Transaction would exceed budget limit",
              budgetCategory: budget.category,
              budgetLimit: budget.limit,
              currentSpent: currentSpent,
              transactionAmount: transactionAmount,
              wouldBeTotal: wouldBeTotal,
              overspendAmount: overspendAmount,
              suggestion: `Reduce amount to ${(budget.limit - currentSpent).toFixed(2)} or less`
            });
          } else {
            fraudDetected = true;
            fraudReason = `This expense exceeds your ${budget.category} budget by $${overspendAmount.toFixed(2)}`;
            riskScore = Math.max(riskScore, 60);
          }
        }
      } 
    }

    // ANOMALY DETECTION: Only check expenses for fraud
    if (type === 'expense') {
      const averageAmount = await calculateAverageTransaction(req.user.userId);
      const absoluteAmount = Math.abs(amount);

      console.log(' Fraud check - Type:', type, 'Amount:', absoluteAmount, 'Average:', averageAmount, 'Threshold:', averageAmount * 5);

      if (absoluteAmount > averageAmount * 5) {
        fraudDetected = true;
        fraudReason = `Amount ($${absoluteAmount}) significantly higher than average spending ($${averageAmount.toFixed(2)})`;
        riskScore = 85;

        console.log(' FRAUD ALERT TRIGGERED:', fraudReason);


         try {
            await prisma.securityLog.create({
              data: {
              userId: req.user.userId,
              action: 'transaction_flagged',
             ipAddress: req.ip,
             details: fraudReason
          }
        });
      } catch (error) {
        console.log(' SecurityLog not available, skipping log');
     }
    }
   }
    
    // Create transaction with fraud detection data
    const transaction = await prisma.transaction.create({
      data: {
        accountId,
        amount: type === 'expense' ? -Math.abs(amount) : Math.abs(amount),
        type,
        category: category.trim(),
        date: new Date(date),
        description: description ? description.trim() : null,
        flagged: fraudDetected,
        fraudReason: fraudDetected ? fraudReason : null,
        riskScore
      },
    });

    console.log(' Transaction saved:', { id: transaction.id, amount: transaction.amount, flagged: transaction.flagged });

    if (fraudDetected) {
      return res.status(201).json({ 
        transaction, 
        warning: 'This transaction has been flagged for review',
        fraudReason
      });
    }

    res.status(201).json(transaction);
    
  } catch (error) {
    console.error("Transaction creation error:", error);
    res.status(500).json({ error: "Failed to create transaction" });
  }
});

// Update transaction WITH VALIDATION
router.put("/:id", authenticateToken, transactionValidation, async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { id } = req.params;
  const { amount, type, category, date, description } = req.body;
  
  // Additional server-side date validation for updates
  const transactionDate = new Date(date);
  const today = new Date();
  today.setHours(23, 59, 59, 999);
  
  if (transactionDate > today) {
    return res.status(400).json({ 
      error: "Future dates are not allowed. Please select today or a past date." 
    });
  }
  
  try {
    const transaction = await prisma.transaction.update({
      where: { 
        id: parseInt(id),
        account: {
          userId: req.user.userId
        }
      },
      data: {
        amount: type === 'expense' ? -Math.abs(amount) : Math.abs(amount),
        type,
        category: category.trim(),
        date: new Date(date),
        description: description ? description.trim() : null
      }
    });
    
    res.json(transaction);
  } catch (error) {
    console.error("Transaction update error:", error);
    res.status(500).json({ error: "Failed to update transaction" });
  }
});

// Delete transaction
router.delete("/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;
  
  try {
    await prisma.transaction.delete({
      where: { 
        id: parseInt(id),
        account: {
          userId: req.user.userId
        }
      }
    });
    
    res.json({ message: "Transaction deleted successfully" });
  } catch (error) {
    console.error("Transaction deletion error:", error);
    res.status(500).json({ error: "Failed to delete transaction" });
  }
});

export { router as default };