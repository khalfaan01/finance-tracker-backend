// fintech-cyber-backend/routes/accounts.js
import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";
import prisma from "../db.js";

const router = express.Router();

// Get all accounts for the logged-in user
router.get("/", authenticateToken, async (req, res) => {
  try {
    const accounts = await prisma.account.findMany({
      where: {
        userId: req.user.userId
      },
      include: {
        transactions: {
          orderBy: {
            date: 'desc'
          },
          take: 10 // Last 10 transactions
        }
      }
    });
    res.json(accounts);
  } catch (error) {
    console.error("Failed to fetch accounts:", error);
    res.status(500).json({ error: "Failed to fetch accounts" });
  }
});

// Create a new account
router.post("/", authenticateToken, async (req, res) => {
  const { name, balance = 0 } = req.body;
  
  try {
    const account = await prisma.account.create({
      data: {
        userId: req.user.userId,
        name,
        balance: parseFloat(balance)
      }
    });
    
    res.status(201).json(account);
  } catch (error) {
    console.error("Account creation error:", error);
    res.status(500).json({ error: "Failed to create account" });
  }
});

// Update account balance
router.put("/:id", authenticateToken, async (req, res) => {
  const { id } = req.params;
  const { balance } = req.body;
  
  try {
    const account = await prisma.account.update({
      where: { 
        id: parseInt(id),
        userId: req.user.userId 
      },
      data: { balance: parseFloat(balance) }
    });
    
    res.json(account);
  } catch (error) {
    console.error("Account update error:", error);
    res.status(500).json({ error: "Failed to update account" });
  }
});

export { router as default };