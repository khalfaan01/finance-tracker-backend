// FINTECH-CYBER-BACKEND/routes/security.js
import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";
import prisma from "../db.js";

const router = express.Router();

// Enhanced fraud detection algorithm
const enhancedFraudDetection = {
  detectTransactionAnomalies: (transaction, userHistory, userBehavior) => {
    const anomalies = [];
    let riskScore = 0;

    // 1. Amount-based detection
    const avgTransaction = userBehavior.avgTransactionAmount || 100;
    const amountRatio = Math.abs(transaction.amount) / avgTransaction;
    
    if (amountRatio > 10) {
      anomalies.push(`Amount ($${Math.abs(transaction.amount)}) is ${amountRatio.toFixed(1)}x higher than average`);
      riskScore += 30;
    }
    
    if (amountRatio > 20) {
      anomalies.push(`CRITICAL: Amount exceeds 20x average spending`);
      riskScore += 25;
    }

    // 2. Time-based detection (unusual hours)
    const transactionHour = new Date().getHours();
    if (transactionHour < 4 || transactionHour > 2) {
      anomalies.push(`Transaction at unusual hour: ${transactionHour}:00`);
      riskScore += 10;
    }

    // 3. Category-based detection
    const categorySpending = userBehavior.categorySpending || {};
    const categoryAvg = categorySpending[transaction.category] || avgTransaction;
    
    if (Math.abs(transaction.amount) > categoryAvg * 3) {
      anomalies.push(`Unusually high amount for ${transaction.category} category`);
      riskScore += 15;
    }

    return { anomalies, riskScore: Math.min(riskScore, 100) };
  }
};

// Get security overview
router.get("/overview", authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;
    
    // Get today's date for daily tracking
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Get today's login attempts
    const todayLoginAttempts = await prisma.securityLog.findMany({
      where: {
        userId: userId,
        action: { in: ['login_success', 'login_failed'] },
        timestamp: {
          gte: today,
          lt: tomorrow
        }
      },
      orderBy: { timestamp: 'desc' }
    });

    // Count successful vs failed for today
    const todaySuccessful = todayLoginAttempts.filter(log => log.action === 'login_success').length;
    const todayFailed = todayLoginAttempts.filter(log => log.action === 'login_failed').length;
    const todayTotal = todaySuccessful + todayFailed;

    // Get all security logs for last 30 days
    const securityLogs = await prisma.securityLog.findMany({
      where: {
        userId: userId,
        timestamp: {
          gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
        }
      },
      orderBy: { timestamp: 'desc' }
    });

    // Build locations array
    const ipLocations = [{
      ip: 'Current Session',
      city: 'Cape Town',
      country: 'South Africa',
      lastLogin: 'Now',
      trusted: true
    }];

    // Get suspicious transactions
    const suspiciousTransactions = await prisma.transaction.findMany({
      where: {
        account: { userId: userId },
        OR: [
          { flagged: true },
          { riskScore: { gt: 30 } }
        ]
      },
      include: { account: true },
      orderBy: { date: 'desc' }
    });

    // Get security events
    const securityEvents = securityLogs
      .filter(log => !['login_success', 'login_failed'].includes(log.action))
      .slice(0, 20)
      .map(log => ({
        type: log.action,
        description: log.details,
        riskLevel: log.riskScore > 80 ? 'high' : 
                  log.riskScore > 60 ? 'medium' : 'low',
        time: log.timestamp.toLocaleString(),
        ip: log.ipAddress
      }));

    res.json({
      loginAttempts: securityLogs.filter(log => 
        log.action === 'login_success' || log.action === 'login_failed'
      ),
      todayLoginStats: {
        total: todayTotal,
        successful: todaySuccessful,
        failed: todayFailed
      },
      suspiciousTransactions,
      securityEvents,
      ipLocations,
      riskScore: Math.min(todayFailed * 10, 100)
    });

  } catch (error) {
    console.error("Security overview error:", error);
    res.status(500).json({ error: "Failed to load security overview" });
  }
});

// Get login attempts
router.get("/login-attempts", authenticateToken, async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 30;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const attempts = await prisma.securityLog.findMany({
      where: {
        userId: req.user.userId,
        action: { in: ['login_success', 'login_failed'] },
        timestamp: { gte: startDate }
      },
      orderBy: { timestamp: 'desc' }
    });

    res.json(attempts);
  } catch (error) {
    console.error("Login attempts error:", error);
    res.status(500).json({ error: "Failed to load login attempts" });
  }
});

// Get suspicious transactions
router.get("/suspicious-transactions", authenticateToken, async (req, res) => {
  try {
    const transactions = await prisma.transaction.findMany({
      where: {
        account: { userId: req.user.userId },
        OR: [
          { flagged: true },
          { riskScore: { gt: 30 } }
        ]
      },
      include: { account: true },
      orderBy: { date: 'desc' }
    });

    res.json(transactions);
  } catch (error) {
    console.error("Suspicious transactions error:", error);
    res.status(500).json({ error: "Failed to load suspicious transactions" });
  }
});

// Update alert preferences
router.post("/alert-preferences", authenticateToken, async (req, res) => {
  try {
    const { emailAlerts } = req.body;
    
    res.json({ 
      success: true, 
      message: `Email alerts ${emailAlerts ? 'enabled' : 'disabled'}` 
    });
  } catch (error) {
    console.error("Alert preferences error:", error);
    res.status(500).json({ error: "Failed to update alert preferences" });
  }
});

// Monitor transaction in real-time
router.post("/monitor-transaction", authenticateToken, async (req, res) => {
  try {
    const transaction = req.body;
    const userId = req.user.userId;

    console.log('🔍 Monitoring transaction for user:', userId, transaction);

    // Get user behavior patterns
    const userTransactions = await prisma.transaction.findMany({
      where: { account: { userId: userId } },
      orderBy: { date: 'desc' },
      take: 100
    });

    // Handle case when user has no transactions yet
    let userBehavior = {
      avgTransactionAmount: 100,
      categorySpending: {},
      recentTransactions: []
    };

    if (userTransactions.length > 0) {
      userBehavior = {
        avgTransactionAmount: userTransactions.reduce((sum, tx) => sum + Math.abs(tx.amount), 0) / userTransactions.length,
        categorySpending: userTransactions.reduce((acc, tx) => {
          acc[tx.category] = (acc[tx.category] || 0) + Math.abs(tx.amount);
          return acc;
        }, {}),
        recentTransactions: userTransactions.slice(0, 10)
      };
    }

    // Enhanced fraud detection
    const detectionResult = enhancedFraudDetection.detectTransactionAnomalies(
      transaction, 
      userTransactions, 
      userBehavior
    );

    console.log(' Fraud detection result:', detectionResult);

    // Log security event if high risk
    if (detectionResult.riskScore > 60) {
      await prisma.securityLog.create({
        data: {
          user: { connect: { id: userId } },
          action: 'transaction_flagged',
          ipAddress: req.ip || '127.0.0.1',
          details: `High-risk transaction detected: ${detectionResult.anomalies.join(', ')}`,
          riskScore: detectionResult.riskScore
        }
      });

      // Trigger real-time alert
      if (req.io) {
        req.io.to(`user_${userId}`).emit('security_alert', {
          type: 'suspicious_transaction',
          message: `Suspicious transaction detected: $${transaction.amount} for ${transaction.category}`,
          riskScore: detectionResult.riskScore,
          timestamp: new Date(),
          ip: req.ip || '127.0.0.1'
        });
      }
    }

    res.json({
      monitored: true,
      riskScore: detectionResult.riskScore,
      anomalies: detectionResult.anomalies,
      alertTriggered: detectionResult.riskScore > 60,
      recommendedAction: detectionResult.riskScore > 80 ? 'block' : 
                        detectionResult.riskScore > 60 ? 'review' : 'allow'
    });

  } catch (error) {
    console.error("Transaction monitoring error:", error);
    res.status(500).json({ error: "Failed to analyze transaction" });
  }
});

// Get security logs
router.get("/logs", authenticateToken, async (req, res) => {
  try {
    const logs = await prisma.securityLog.findMany({
      where: { userId: req.user.userId },
      orderBy: { timestamp: 'desc' },
      take: 50
    });

    res.json(logs);
  } catch (error) {
    console.error("Security logs error:", error);
    res.status(500).json({ error: "Failed to load security logs" });
  }
});

export default router;