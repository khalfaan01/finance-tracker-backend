import express from "express";
import { authenticateToken } from "../middleware/authMiddleware.js";
import prisma from "../db.js";

const router = express.Router();

// Get all debts for user
router.get("/", authenticateToken, async (req, res) => {
  try {
    const debts = await prisma.debt.findMany({
      where: { userId: req.user.userId },
      orderBy: { dueDate: 'asc' }
    });
    
    // Calculate additional metrics for each debt
    const debtsWithMetrics = debts.map(debt => {
      const metrics = calculateDebtMetrics(debt);
      return { ...debt, ...metrics };
    });
    
    res.json(debtsWithMetrics);
  } catch (error) {
    console.error("Get debts error:", error);
    res.status(500).json({ error: "Failed to fetch debts" });
  }
});

// Get debt by ID
router.get("/:id", authenticateToken, async (req, res) => {
  try {
    const debt = await prisma.debt.findFirst({
      where: { 
        id: parseInt(req.params.id),
        userId: req.user.userId 
      }
    });
    
    if (!debt) {
      return res.status(404).json({ error: "Debt not found" });
    }
    
    const metrics = calculateDebtMetrics(debt);
    res.json({ ...debt, ...metrics });
  } catch (error) {
    console.error("Get debt error:", error);
    res.status(500).json({ error: "Failed to fetch debt" });
  }
});

// Create new debt
router.post("/", authenticateToken, async (req, res) => {
  try {
    const {
      name,
      type,
      principal,
      balance,
      interestRate,
      minimumPayment,
      startDate,
      dueDate,
      termMonths,
      lender,
      accountNumber,
      notes
    } = req.body;

    const debt = await prisma.debt.create({
      data: {
        userId: req.user.userId,
        name,
        type,
        principal: parseFloat(principal),
        balance: parseFloat(balance),
        interestRate: parseFloat(interestRate),
        minimumPayment: parseFloat(minimumPayment),
        startDate: new Date(startDate),
        dueDate: dueDate ? new Date(dueDate) : null,
        termMonths: termMonths ? parseInt(termMonths) : null,
        lender,
        accountNumber,
        notes
      }
    });

    const metrics = calculateDebtMetrics(debt);
    res.status(201).json({ ...debt, ...metrics });
  } catch (error) {
    console.error("Create debt error:", error);
    res.status(500).json({ error: "Failed to create debt" });
  }
});

// Update debt
router.put("/:id", authenticateToken, async (req, res) => {
  try {
    const {
      name,
      type,
      principal,
      balance,
      interestRate,
      minimumPayment,
      dueDate,
      termMonths,
      lender,
      accountNumber,
      notes,
      isActive
    } = req.body;

    // Verify debt belongs to user
    const existingDebt = await prisma.debt.findFirst({
      where: { 
        id: parseInt(req.params.id),
        userId: req.user.userId 
      }
    });

    if (!existingDebt) {
      return res.status(404).json({ error: "Debt not found" });
    }

    const debt = await prisma.debt.update({
      where: { id: parseInt(req.params.id) },
      data: {
        name,
        type,
        principal: principal ? parseFloat(principal) : undefined,
        balance: balance ? parseFloat(balance) : undefined,
        interestRate: interestRate ? parseFloat(interestRate) : undefined,
        minimumPayment: minimumPayment ? parseFloat(minimumPayment) : undefined,
        dueDate: dueDate ? new Date(dueDate) : undefined,
        termMonths: termMonths ? parseInt(termMonths) : undefined,
        lender,
        accountNumber,
        notes,
        isActive: isActive !== undefined ? isActive : undefined
      }
    });

    const metrics = calculateDebtMetrics(debt);
    res.json({ ...debt, ...metrics });
  } catch (error) {
    console.error("Update debt error:", error);
    res.status(500).json({ error: "Failed to update debt" });
  }
});

// Delete debt
router.delete("/:id", authenticateToken, async (req, res) => {
  try {
    // Verify debt belongs to user
    const existingDebt = await prisma.debt.findFirst({
      where: { 
        id: parseInt(req.params.id),
        userId: req.user.userId 
      }
    });

    if (!existingDebt) {
      return res.status(404).json({ error: "Debt not found" });
    }

    await prisma.debt.delete({
      where: { id: parseInt(req.params.id) }
    });

    res.json({ message: "Debt deleted successfully" });
  } catch (error) {
    console.error("Delete debt error:", error);
    res.status(500).json({ error: "Failed to delete debt" });
  }
});

// Make payment on debt - UPDATED TO CREATE TRANSACTION
router.post("/:id/payment", authenticateToken, async (req, res) => {
  try {
    const { amount, paymentDate, accountId, description } = req.body;

    const existingDebt = await prisma.debt.findFirst({
      where: { 
        id: parseInt(req.params.id),
        userId: req.user.userId 
      }
    });

    if (!existingDebt) {
      return res.status(404).json({ error: "Debt not found" });
    }

    // Start a transaction to ensure both operations succeed or fail together
    const result = await prisma.$transaction(async (prisma) => {
      // Update debt balance
      const newBalance = existingDebt.balance - parseFloat(amount);
      const nextDueDate = new Date(paymentDate);
      nextDueDate.setMonth(nextDueDate.getMonth() + 1);

      const debt = await prisma.debt.update({
        where: { id: parseInt(req.params.id) },
        data: {
          balance: Math.max(0, newBalance),
          dueDate: nextDueDate,
          paymentsMade: existingDebt.paymentsMade + 1,
          isActive: newBalance > 0
        }
      });

      // Create transaction record for the payment
      const transaction = await prisma.transaction.create({
        data: {
          accountId: parseInt(accountId),
          amount: -parseFloat(amount), // Negative for expense
          type: "expense",
          category: "Debt Payment",
          date: new Date(paymentDate),
          description: description || `Payment for ${existingDebt.name}`,
          flagged: false,
          riskScore: 0,
          reviewed: true
        }
      });

      // Update account balance
      await prisma.account.update({
        where: { id: parseInt(accountId) },
        data: {
          balance: {
            decrement: parseFloat(amount)
          }
        }
      });

      return { debt, transaction };
    });

    const metrics = calculateDebtMetrics(result.debt);
    res.json({ 
      ...result.debt, 
      ...metrics,
      paymentApplied: parseFloat(amount),
      newBalance: Math.max(0, newBalance),
      transactionCreated: result.transaction
    });
  } catch (error) {
    console.error("Payment error:", error);
    res.status(500).json({ error: "Failed to process payment" });
  }
});

// Get debt summary and analytics
router.get("/analytics/summary", authenticateToken, async (req, res) => {
  try {
    const debts = await prisma.debt.findMany({
      where: { 
        userId: req.user.userId,
        isActive: true 
      }
    });

    const summary = calculateDebtSummary(debts);
    res.json(summary);
  } catch (error) {
    console.error("Debt analytics error:", error);
    res.status(500).json({ error: "Failed to generate debt analytics" });
  }
});

// Helper function to calculate debt metrics
function calculateDebtMetrics(debt) {
  const monthlyInterestRate = debt.interestRate / 100 / 12;
  const remainingBalance = debt.balance;
  
  // Calculate estimated payoff time
  let estimatedPayoffMonths = null;
  let totalInterest = 0;
  
  if (debt.minimumPayment > 0 && monthlyInterestRate > 0) {
    estimatedPayoffMonths = Math.ceil(
      Math.log(debt.minimumPayment / (debt.minimumPayment - remainingBalance * monthlyInterestRate)) / 
      Math.log(1 + monthlyInterestRate)
    );
    
    totalInterest = (debt.minimumPayment * estimatedPayoffMonths) - remainingBalance;
  }
  
  // Calculate progress percentage
  const progressPercentage = debt.principal > 0 ? 
    ((debt.principal - remainingBalance) / debt.principal) * 100 : 0;
  
  return {
    estimatedPayoffMonths,
    totalInterest: Math.max(0, totalInterest),
    progressPercentage: Math.min(100, Math.max(0, progressPercentage)),
    monthlyInterest: remainingBalance * monthlyInterestRate,
    isOnTrack: debt.minimumPayment > (remainingBalance * monthlyInterestRate)
  };
}

// Helper function to calculate debt summary
function calculateDebtSummary(debts) {
  const totalDebt = debts.reduce((sum, debt) => sum + debt.balance, 0);
  const totalMinimumPayments = debts.reduce((sum, debt) => sum + debt.minimumPayment, 0);
  const totalInterest = debts.reduce((sum, debt) => {
    const monthlyInterest = debt.balance * (debt.interestRate / 100 / 12);
    return sum + monthlyInterest;
  }, 0);
  
  const debtByType = debts.reduce((acc, debt) => {
    acc[debt.type] = (acc[debt.type] || 0) + debt.balance;
    return acc;
  }, {});
  
  return {
    totalDebt,
    totalMinimumPayments,
    totalMonthlyInterest: totalInterest,
    debtCount: debts.length,
    debtByType,
    highestInterestDebt: debts.length > 0 ? 
      debts.reduce((max, debt) => debt.interestRate > max.interestRate ? debt : max) : null,
    snowballOrder: [...debts].sort((a, b) => a.balance - b.balance), // Debt snowball method
    avalancheOrder: [...debts].sort((a, b) => b.interestRate - a.interestRate) // Debt avalanche method
  };
}

export default router;